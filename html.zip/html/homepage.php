<?php include './header.php' ?>
<section class="banner-1">
    <picture>
        <img src="./dist/img/Rectangle 1.png" alt="">
    </picture>
</section>
<section class="banner-2">
    <picture>
        <img src="./dist/img/Rectangle 17.png" alt="">
    </picture>
    <div class="text-banner">
        <p>V-Top Media</p>
        <h4>Management Consult Meida Services</h4>
        <p>Khởi Việt Media là công ty truyền thông chuyên cung cấp các dịch vụ truyền thông và quảng cáo tích hợp giữa sản xuất video</p>
        <a href="#">Tìm hiểu thêm</a>
    </div>
</section>
<div class="container">
    <section class="about-us-1">
        <div class="about-text">
            <h4>Giới thiệu chung</h4>
            <div class="about-text-child">
                <p>Khởi Việt Media là công ty truyền thông chuyên cung cấp các dịch vụ truyền thông và quảng cáo tích hợp giữa sản xuất video với marketing thông qua các trang mạng xã hội phổ biến: Tiktok, Facebook, Youtube, Instagram... </p>
                <p>Chúng tôi đặt mục tiêu truyền tải và nâng cao giá trị thương hiệu thông qua các giải pháp video marketing rất riêng cho doanh nghiệp</p>
            </div>
            <a href="#">Về chúng tôi</a>
        </div>
        <div class="about-image">
            <div class="about-image-1">
                <picture>
                    <img src="./dist/img/Rectangle 2.png" alt="">
                </picture>
            </div>
            <div class="about-image-2">
                <picture>
                    <img src="./dist/img/Rectangle 3.png" alt="">
                </picture>
            </div>
            <div class="about-image-3">
                <picture>
                    <img src="./dist/img/Rectangle 4.png" alt="">
                </picture>
            </div>
        </div>
    </section>
    <section class="about-us-2">
        <div class="about-image">
            <picture>
                <img src="./dist/img/Rectangle 3.png" alt="">
            </picture>
        </div>
        <div class="about-text">
            <h4>Giới thiệu chung</h4>
            <div class="about-text-child">
                <p>Khởi Việt Media là công ty truyền thông chuyên cung cấp các dịch vụ truyền thông và quảng cáo tích hợp giữa sản xuất video với marketing thông qua các trang mạng xã hội phổ biến: Tiktok, Facebook, Youtube, Instagram... Chúng tôi đặt mục tiêu truyền tải và nâng cao giá trị thương hiệu thông qua các giải pháp video marketing rất riêng cho doanh nghiệp.</p>
            </div>
            <a href="#">Về chúng tôi</a>
        </div>
    </section>
    <section class="about-us-3">
        <div class="about-us-3-title">
            <h4>Về chúng tôi</h4>
            <p>Khởi Việt Media là công ty truyền thông chuyên cung cấp các dịch vụ truyền thông và quảng cáo tích hợp giữa sản xuất video với marketing thông qua các trang mạng xã hội phổ biến.</p>
        </div>
        <div class="about-us-3-wrapper">
            <div class="about-us-3-child">
                <h5>Our vision</h5>
                <p>Khởi Việt Media là công ty truyền thông chuyên cung cấp các dịch vụ truyền thông và quảng cáo tích hợp giữa sản xuất video với marketing</p>
            </div>
            <div class="about-us-3-child">
                <h5>Our mission</h5>
                <p>Khởi Việt Media là công ty truyền thông chuyên cung cấp các dịch vụ truyền thông và quảng cáo tích hợp giữa sản xuất video với marketing</p>
            </div>
            <div class="about-us-3-child">
                <h5>Why us</h5>
                <p>Khởi Việt Media là công ty truyền thông chuyên cung cấp các dịch vụ truyền thông và quảng cáo tích hợp giữa sản xuất video với marketing</p>
            </div>
        </div>
    </section>
</div>
<section class="field-activity-1">
    <div class="field-activity-image">
        <picture>
            <img src="./dist/img/Rectangle 5.png" alt="">
        </picture>
    </div>
    <div class="field-activity-text">
        <div class="field-activity-text-child">
            <h4>Lĩnh vực hoạt động</h4>
            <p>Khởi Việt Media là công ty truyền thông chuyên cung cấp các dịch vụ truyền thông và quảng cáo tích hợp giữa sản xuất video</p>
        </div>
        <div class="tabs">
            <div class="tabs-child">
                <div class="tabs-title">
                    <h5>Quản lý KOLs</h5>
                </div>
                <div class="tabs-content">
                    <p>Cras a elit sit amet leo accumsan volutpat. Suspendisse hendrerit vehicula leo, vel efficitur felis ultrices non. Integer aliquet ullamcorper dolor, quis sollicitudin.</p>
                    <a href="#">Xem thêm</a>
                </div>
            </div>
            <div class="tabs-child showw">
                <div class="tabs-title">
                    <h5>Sản xuất virual video</h5>
                </div>
                <div class="tabs-content">
                    <p>Cras a elit sit amet leo accumsan volutpat. Suspendisse hendrerit vehicula leo, vel efficitur felis ultrices non. Integer aliquet ullamcorper dolor, quis sollicitudin.</p>
                    <a href="#">Xem thêm</a>
                </div>
            </div>
            <div class="tabs-child">
                <div class="tabs-title">
                    <h5>Business Coaching</h5>
                </div>
                <div class="tabs-content">
                    <p>Cras a elit sit amet leo accumsan volutpat. Suspendisse hendrerit vehicula leo, vel efficitur felis ultrices non. Integer aliquet ullamcorper dolor, quis sollicitudin.</p>
                    <a href="#">Xem thêm</a>
                </div>
            </div>
            <div class="tabs-child">
                <div class="tabs-title">
                    <h5>Service Benchmarking</h5>
                </div>
                <div class="tabs-content">
                    <p>Cras a elit sit amet leo accumsan volutpat. Suspendisse hendrerit vehicula leo, vel efficitur felis ultrices non. Integer aliquet ullamcorper dolor, quis sollicitudin.</p>
                    <a href="#">Xem thêm</a>
                </div>
            </div>
        </div>
        <div class="learn-more">
            <a href="#">Tìm hiểu thêm</a>
        </div>
    </div>
</section>
<section class="field-activity-2">
    <div class="container">
        <div class="field-activity-title">
            <h4>Lĩnh vực hoạt động</h4>
            <p>Business</p>
        </div>
        <div class="field-activity-list">
            <div class="field-activity-child">
                <picture>
                    <img src="./dist/img/Rectangle 19.png" alt="">
                </picture>
                <h5>Sáng tạo nội dung</h5>
                <p>Là đơn vị truyền thông hàng đầu Việt Nam, Khởi Việt tự hào luôn mang đến sự hài lòng và niềm tin mạnh mẽ cho khách hàng</p>
            </div>
            <div class="field-activity-child">
                <picture>
                    <img src="./dist/img/Rectangle 20.png" alt="">
                </picture>
                <h5>Đào tạo KOLs</h5>
                <p>Là đơn vị truyền thông hàng đầu Việt Nam, Khởi Việt tự hào luôn mang đến sự hài lòng và niềm tin mạnh mẽ cho khách hàng</p>
            </div>
            <div class="field-activity-child">
                <picture>
                    <img src="./dist/img/Rectangle 19.png" alt="">
                </picture>
                <h5>Quản lý</h5>
                <p>Là đơn vị truyền thông hàng đầu Việt Nam, Khởi Việt tự hào luôn mang đến sự hài lòng và niềm tin mạnh mẽ cho khách hàng</p>
            </div>
        </div>
    </div>
</section>
<section class="featured-works-1">
    <div class="container">
        <div class="featured-works-text">
            <h4>Tác phẩm nổi bật</h4>
            <p>V-Top luôn mang đến sự hài lòng, là sự lựa chọn sáng giá được các đối tác ưu tiên tìm gặp hợp tác, đặt niềm tin vào sản phẩm dịch vụ của chúng tôi</p>
        </div>
        <div class="featured-works-slider">
            <div class="featured-works-child">
                <picture>
                    <img src="./dist/img/Rectangle 2.png" alt="">
                </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
            </div>
            <div class="featured-works-child">
                <picture>
                    <img src="./dist/img/Rectangle 6.png" alt="">
                </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
            </div>
            <div class="featured-works-child">
                <picture>
                    <img src="./dist/img/Rectangle 2.png" alt="">
                </picture>
            </div>
            <div class="featured-works-child">
                <picture>
                    <img src="./dist/img/Rectangle 2.png" alt="">
                </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
            </div>
            <div class="featured-works-child">
                <picture>
                    <img src="./dist/img/Rectangle 6.png" alt="">
                </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
            </div>
            <div class="featured-works-child">
                <picture>
                    <img src="./dist/img/Rectangle 2.png" alt="">
                </picture>
            </div>
        </div>
   
    </div>
</section>
<section class="featured-works-2">
    <div class="container">
        <div class="featured-works-text">
            <h4>Tác phẩm nổi bật</h4>
            <p>V-Top luôn mang đến sự hài lòng, là sự lựa chọn sáng giá được các đối tác ưu tiên tìm gặp hợp tác, đặt niềm tin vào sản phẩm dịch vụ của chúng tôi</p>
        </div>
        <div class="featured-works-slider">
            <div class="featured-works-child">
                <picture>
                    <img src="./dist/img/Rectangle 2.png" alt="">
                </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
            </div>
            <div class="featured-works-child">
                <picture>
                    <img src="./dist/img/Rectangle 6.png" alt="">
                </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
            </div>
            <div class="featured-works-child">
                <picture>
                    <img src="./dist/img/Rectangle 2.png" alt="">
                </picture>
            </div>
            <div class="featured-works-child">
                <picture>
                    <img src="./dist/img/Rectangle 2.png" alt="">
                </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
            </div>
            <div class="featured-works-child">
                <picture>
                    <img src="./dist/img/Rectangle 6.png" alt="">
                </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
            </div>
            <div class="featured-works-child">
                <picture>
                    <img src="./dist/img/Rectangle 2.png" alt="">
                </picture>
            </div>
        </div>
   
    </div>
</section>
<section class="featured-works-3">
    <div class="container">
        <div class="featured-works-text">
            <h4>Tác phẩm nổi bật</h4>
            <p>V-Top luôn mang đến sự hài lòng, là sự lựa chọn sáng giá được các đối tác ưu tiên tìm gặp hợp tác, đặt niềm tin vào sản phẩm dịch vụ của chúng tôi</p>
        </div>
        <div class="featured-works-slider">
            <div class="featured-works-child">
                <picture>
                    <img src="./dist/img/Rectangle 2.png" alt="">
                </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
            </div>
            <div class="featured-works-child">
                <picture>
                    <img src="./dist/img/Rectangle 6.png" alt="">
                </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
            </div>
            <div class="featured-works-child">
                <picture>
                    <img src="./dist/img/Rectangle 2.png" alt="">
                </picture>
            </div>
            <div class="featured-works-child">
                <picture>
                    <img src="./dist/img/Rectangle 2.png" alt="">
                </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
            </div>
            <div class="featured-works-child">
                <picture>
                    <img src="./dist/img/Rectangle 6.png" alt="">
                </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
            </div>
            <div class="featured-works-child">
                <picture>
                    <img src="./dist/img/Rectangle 2.png" alt="">
                </picture>
            </div>
        </div>
   
    </div>
</section>
<section class="featured-works-4">
    <div class="container">
        <div class="featured-works-text">
            <h4>Tác phẩm nổi bật</h4>
            <p>V-Top luôn mang đến sự hài lòng, là sự lựa chọn sáng giá được các đối tác ưu tiên tìm gặp hợp tác, đặt niềm tin vào sản phẩm dịch vụ của chúng tôi</p>
            <div class="tabs-title">
                <ul>
                    <li class="tabs-link" onclick="openCity(event, '1')" id="defaultOpen">Lượt xem nhiều nhất</li>
                    <li class="tabs-link" onclick="openCity(event, '2')">Mới và mới nổi</li>
                    <li class="tabs-link" onclick="openCity(event, '3')">Phổ biến nhất</li>
                    <li class="tabs-link" onclick="openCity(event, '4')">Mới và mới nổi</li>
                </ul>
            </div>
        </div>
        <div class="tabs-content" id="1">
            <div class="tabs-content-wrapper">
                <div class="tabs-content-child width">
                    <picture>
                        <img src="./dist/img/Rectangle 22.png" alt="">
                    </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
                </div>
                <div class="tabs-content-child">
                    <picture>
                        <img src="./dist/img/Rectangle 23.png" alt="">
                    </picture>
                </div>
                <div class="tabs-content-child">
                    <picture>
                        <img src="./dist/img/Rectangle 24.png" alt="">
                    </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
                </div>
                <div class="tabs-content-child">
                    <picture>
                        <img src="./dist/img/Rectangle 23.png" alt="">
                    </picture>
                </div>
                <div class="tabs-content-child width">
                    <picture>
                        <img src="./dist/img/Rectangle 22.png" alt="">
                    </picture>
                </div>
                <div class="tabs-content-child">
                    <picture>
                        <img src="./dist/img/Rectangle 24.png" alt="">
                    </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
                </div>
            </div>
            <a href="#">Xem tất cả</a>
        </div>
        <div class="tabs-content" id="2">
            <div class="tabs-content-wrapper">
                <div class="tabs-content-child width">
                    <picture>
                        <img src="./dist/img/Rectangle 22.png" alt="">
                    </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
                </div>
                <div class="tabs-content-child">
                    <picture>
                        <img src="./dist/img/Rectangle 23.png" alt="">
                    </picture>
                </div>
                <div class="tabs-content-child">
                    <picture>
                        <img src="./dist/img/Rectangle 24.png" alt="">
                    </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
                </div>
                <div class="tabs-content-child">
                    <picture>
                        <img src="./dist/img/Rectangle 23.png" alt="">
                    </picture>
                </div>
                <div class="tabs-content-child width">
                    <picture>
                        <img src="./dist/img/Rectangle 22.png" alt="">
                    </picture>
                </div>
                <div class="tabs-content-child">
                    <picture>
                        <img src="./dist/img/Rectangle 24.png" alt="">
                    </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
                </div>
            </div>
            <a href="#">Xem tất cả</a>
        </div>
        <div class="tabs-content" id="3">
            <div class="tabs-content-wrapper">
                <div class="tabs-content-child width">
                    <picture>
                        <img src="./dist/img/Rectangle 22.png" alt="">
                    </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
                </div>
                <div class="tabs-content-child">
                    <picture>
                        <img src="./dist/img/Rectangle 23.png" alt="">
                    </picture>
                </div>
                <div class="tabs-content-child">
                    <picture>
                        <img src="./dist/img/Rectangle 24.png" alt="">
                    </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
                </div>
                <div class="tabs-content-child">
                    <picture>
                        <img src="./dist/img/Rectangle 23.png" alt="">
                    </picture>
                </div>
                <div class="tabs-content-child width">
                    <picture>
                        <img src="./dist/img/Rectangle 22.png" alt="">
                    </picture>
                </div>
                <div class="tabs-content-child">
                    <picture>
                        <img src="./dist/img/Rectangle 24.png" alt="">
                    </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
                </div>
            </div>
            <a href="#">Xem tất cả</a>
        </div>
        <div class="tabs-content" id="4">
            <div class="tabs-content-wrapper">
                <div class="tabs-content-child width">
                    <picture>
                        <img src="./dist/img/Rectangle 22.png" alt="">
                    </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
                </div>
                <div class="tabs-content-child">
                    <picture>
                        <img src="./dist/img/Rectangle 23.png" alt="">
                    </picture>
                </div>
                <div class="tabs-content-child">
                    <picture>
                        <img src="./dist/img/Rectangle 24.png" alt="">
                    </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
                </div>
                <div class="tabs-content-child">
                    <picture>
                        <img src="./dist/img/Rectangle 23.png" alt="">
                    </picture>
                </div>
                <div class="tabs-content-child width">
                    <picture>
                        <img src="./dist/img/Rectangle 22.png" alt="">
                    </picture>
                </div>
                <div class="tabs-content-child">
                    <picture>
                        <img src="./dist/img/Rectangle 24.png" alt="">
                    </picture>
                    <a href="https://www.youtube.com/watch?v=UVbv-PJXm14" data-fancybox="video">
                        <svg width="60" height="60" viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path d="M47.675 49.5498C47.2 49.5498 46.725 49.3748 46.35 48.9998C45.625 48.2748 45.625 47.0748 46.35 46.3498C55.375 37.3248 55.375 22.6498 46.35 13.6498C45.625 12.9248 45.625 11.7248 46.35 10.9998C47.075 10.2748 48.275 10.2748 49 10.9998C59.475 21.4748 59.475 38.5248 49 48.9998C48.625 49.3748 48.15 49.5498 47.675 49.5498Z" fill="white"/>
                            <path d="M12.325 49.5498C11.85 49.5498 11.375 49.3748 11 48.9998C0.524987 38.5248 0.524987 21.4748 11 10.9998C11.725 10.2748 12.925 10.2748 13.65 10.9998C14.375 11.7248 14.375 12.9248 13.65 13.6498C4.62499 22.6748 4.62499 37.3498 13.65 46.3498C14.375 47.0748 14.375 48.2748 13.65 48.9998C13.275 49.3748 12.8 49.5498 12.325 49.5498Z" fill="white"/>
                            <path d="M30 56.7749C26.875 56.7499 23.9 56.2499 21.125 55.2749C20.15 54.9249 19.625 53.8499 19.975 52.8749C20.325 51.8999 21.375 51.3749 22.375 51.7249C24.775 52.5499 27.325 52.9999 30.025 52.9999C32.7 52.9999 35.275 52.5499 37.65 51.7249C38.625 51.3999 39.7 51.8999 40.05 52.8749C40.4 53.8499 39.875 54.9249 38.9 55.2749C36.1 56.2499 33.125 56.7749 30 56.7749Z" fill="white"/>
                            <path d="M38.25 8.3501C38.05 8.3501 37.825 8.3251 37.625 8.2501C35.25 7.4001 32.675 6.9751 30 6.9751C27.325 6.9751 24.775 7.4251 22.375 8.2501C21.375 8.5751 20.325 8.0751 19.975 7.1001C19.625 6.1251 20.15 5.0501 21.125 4.7001C23.925 3.7251 26.9 3.2251 30 3.2251C33.1 3.2251 36.1 3.7251 38.875 4.7001C39.85 5.0501 40.375 6.1251 40.025 7.1001C39.75 7.8751 39.025 8.3501 38.25 8.3501Z" fill="white"/>
                            <path d="M21.85 29.9999V25.8249C21.85 20.6249 25.525 18.4999 30.025 21.0999L33.65 23.1999L37.275 25.2999C41.775 27.8999 41.775 32.1499 37.275 34.7499L33.65 36.8499L30.025 38.9499C25.525 41.5499 21.85 39.4249 21.85 34.2249V29.9999Z" fill="white"/>
                        </svg>
                    </a>
                </div>
            </div>
            <a href="#">Xem tất cả</a>
        </div>
    </div>
</section>
<div class="container">
    <section class="public-figure">
        <div class="public-figure-text">
            <h4>Nhân vật công chúng</h4>
            <p>KOLs tại V-Top</p>
        </div>
        <div class="public-figure-list">
            <div class="public-figure-child">
                <picture>
                    <img src="./dist/img/Rectangle 7.png" alt="">
                </picture>
                <div class="public-figure-child-info">
                    <div>
                        <h5 class="btn-show-info">Linda Gaming</h5>
                        <p>V-Top Channel</p>
                    </div>
                    <ul>
                        <li>12M lượt thích trên tiktok</li>
                        <li>10M followers</li>
                        <li>1000 virual videos</li>
                    </ul>
                    <div class="socail-info">
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#3B5998"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M20.7648 12.0119C20.3233 11.9236 19.7269 11.8577 19.3519 11.8577C18.3364 11.8577 18.2704 12.2992 18.2704 13.0056V14.2632H20.8089L20.5877 16.8682H18.2704V24.7918H15.092V16.8682H13.4583V14.2632H15.092V12.6519C15.092 10.4448 16.1293 9.2085 18.7338 9.2085C19.6386 9.2085 20.3009 9.34096 21.1616 9.51757L20.7648 12.0119Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#1DA1F2"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M25.5 11.5518C24.875 11.8294 24.2024 12.0164 23.497 12.1009C24.2172 11.6691 24.7702 10.9857 25.0303 10.1715C24.3571 10.5715 23.6097 10.8611 22.8159 11.018C22.1796 10.3403 21.2724 9.9165 20.27 9.9165C18.344 9.9165 16.7824 11.4781 16.7824 13.4041C16.7824 13.6772 16.8136 13.9435 16.8731 14.1991C13.9742 14.054 11.4045 12.6652 9.68425 10.5551C9.38394 11.0702 9.21225 11.6691 9.21225 12.3082C9.21225 13.518 9.82704 14.5855 10.7637 15.2111C10.1914 15.193 9.65422 15.036 9.18335 14.7748V14.8184C9.18335 16.5087 10.3863 17.9179 11.9808 18.2392C11.6884 18.3185 11.3802 18.3615 11.0623 18.3615C10.8373 18.3615 10.6186 18.3394 10.4056 18.2986C10.8492 19.6841 12.1378 20.6927 13.6637 20.721C12.4704 21.6559 10.9665 22.2141 9.33238 22.2141C9.0502 22.2141 8.77255 22.1976 8.5 22.1648C10.0435 23.1541 11.8765 23.7321 13.8461 23.7321C20.2609 23.7321 23.7689 18.4176 23.7689 13.8092C23.7689 13.658 23.7661 13.5072 23.7588 13.3582C24.441 12.8652 25.0325 12.251 25.5 11.5518Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#C13584"/>
                            <path d="M17 10.0315C19.2696 10.0315 19.5384 10.0402 20.4347 10.0811C21.2635 10.1189 21.7135 10.2573 22.0131 10.3738C22.4098 10.528 22.693 10.7121 22.9904 11.0096C23.2878 11.307 23.472 11.5902 23.6262 11.9869C23.7426 12.2864 23.8811 12.7365 23.9189 13.5653C23.9598 14.4615 23.9685 14.7304 23.9685 17C23.9685 19.2696 23.9598 19.5384 23.9189 20.4347C23.8811 21.2634 23.7426 21.7135 23.6262 22.013C23.472 22.4098 23.2878 22.6929 22.9904 22.9903C22.693 23.2878 22.4098 23.472 22.0131 23.6262C21.7135 23.7426 21.2635 23.8811 20.4347 23.9189C19.5386 23.9597 19.2698 23.9684 17 23.9684C14.7302 23.9684 14.4615 23.9597 13.5653 23.9189C12.7365 23.8811 12.2865 23.7426 11.9869 23.6262C11.5902 23.472 11.307 23.2878 11.0096 22.9903C10.7122 22.6929 10.528 22.4098 10.3738 22.013C10.2574 21.7135 10.1189 21.2634 10.0811 20.4347C10.0402 19.5384 10.0315 19.2696 10.0315 17C10.0315 14.7304 10.0402 14.4615 10.0811 13.5653C10.1189 12.7365 10.2574 12.2864 10.3738 11.9869C10.528 11.5902 10.7121 11.307 11.0096 11.0096C11.307 10.7121 11.5902 10.528 11.9869 10.3738C12.2865 10.2573 12.7365 10.1189 13.5653 10.0811C14.4616 10.0402 14.7304 10.0315 17 10.0315ZM17 8.5C14.6915 8.5 14.4021 8.50978 13.4955 8.55115C12.5907 8.59242 11.9728 8.73612 11.4322 8.94622C10.8732 9.16344 10.3992 9.45409 9.92663 9.92662C9.45409 10.3992 9.16345 10.8732 8.94626 11.4322C8.73612 11.9728 8.59242 12.5907 8.55115 13.4954C8.50978 14.4021 8.5 14.6915 8.5 17C8.5 19.3084 8.50978 19.5979 8.55115 20.5045C8.59242 21.4092 8.73612 22.0271 8.94626 22.5678C9.16345 23.1267 9.45409 23.6007 9.92663 24.0733C10.3992 24.5459 10.8732 24.8365 11.4322 25.0537C11.9728 25.2638 12.5907 25.4075 13.4955 25.4488C14.4021 25.4902 14.6915 25.4999 17 25.4999C19.3085 25.4999 19.5979 25.4902 20.5045 25.4488C21.4093 25.4075 22.0272 25.2638 22.5678 25.0537C23.1268 24.8365 23.6008 24.5459 24.0734 24.0733C24.5459 23.6007 24.8366 23.1267 25.0538 22.5678C25.2639 22.0271 25.4076 21.4092 25.4488 20.5045C25.4902 19.5979 25.5 19.3084 25.5 17C25.5 14.6915 25.4902 14.4021 25.4488 13.4954C25.4076 12.5907 25.2639 11.9728 25.0538 11.4322C24.8366 10.8732 24.5459 10.3992 24.0734 9.92662C23.6008 9.45409 23.1268 9.16344 22.5678 8.94622C22.0272 8.73612 21.4093 8.59242 20.5045 8.55115C19.5979 8.50978 19.3085 8.5 17 8.5Z" fill="white"/>
                            <path d="M17.0039 12.6392C14.5933 12.6392 12.6391 14.5934 12.6391 17.004C12.6391 19.4147 14.5933 21.3689 17.0039 21.3689C19.4146 21.3689 21.3688 19.4147 21.3688 17.004C21.3688 14.5934 19.4146 12.6392 17.0039 12.6392ZM17.0039 19.8373C15.4391 19.8373 14.1706 18.5688 14.1706 17.004C14.1706 15.4392 15.4391 14.1707 17.0039 14.1707C18.5687 14.1707 19.8373 15.4392 19.8373 17.004C19.8373 18.5688 18.5687 19.8373 17.0039 19.8373Z" fill="white"/>
                            <path d="M22.561 12.4639C22.561 13.0272 22.1043 13.4838 21.541 13.4838C20.9777 13.4838 20.521 13.0272 20.521 12.4639C20.521 11.9005 20.9777 11.4438 21.541 11.4438C22.1043 11.4438 22.561 11.9005 22.561 12.4639Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#FF0000"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M25.0045 11.6011C25.2872 11.8838 25.4909 12.2356 25.5953 12.6216C26.1966 15.042 26.0577 18.8646 25.607 21.3784C25.5026 21.7643 25.2989 22.1162 25.0162 22.3989C24.7335 22.6816 24.3817 22.8853 23.9957 22.9897C22.583 23.375 16.8968 23.375 16.8968 23.375C16.8968 23.375 11.2107 23.375 9.79794 22.9897C9.41203 22.8853 9.0602 22.6816 8.77751 22.3989C8.49481 22.1162 8.29111 21.7643 8.18668 21.3784C7.58187 18.9685 7.74767 15.1435 8.175 12.6332C8.27943 12.2473 8.48314 11.8955 8.76583 11.6128C9.04853 11.3301 9.40035 11.1264 9.78627 11.022C11.199 10.6367 16.8852 10.625 16.8852 10.625C16.8852 10.625 22.5713 10.625 23.9841 11.0103C24.37 11.1147 24.7218 11.3184 25.0045 11.6011ZM19.7924 17L15.0754 19.7321V14.2679L19.7924 17Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#161414"/>
                            <path d="M12.9895 19.0146C13.0725 18.3272 13.3544 17.9424 13.8857 17.5478C14.6459 17.0135 15.5954 17.3158 15.5954 17.3158V15.5227C15.8262 15.5168 16.0572 15.5305 16.2855 15.5636V17.8711C16.2855 17.8711 15.3362 17.5688 14.5761 18.1034C14.0451 18.4977 13.7626 18.8828 13.6799 19.5702C13.6773 19.9435 13.7473 20.4314 14.0699 20.8533C13.9902 20.8124 13.9089 20.7658 13.826 20.7135C13.1155 20.2363 12.986 19.5205 12.9895 19.0146ZM20.2061 12.2074C19.6832 11.6344 19.4855 11.0558 19.414 10.6494H20.0718C20.0718 10.6494 19.9406 11.715 20.8965 12.763L20.9098 12.777C20.6521 12.615 20.4159 12.4237 20.2061 12.2074ZM23.375 13.8319V16.093C23.375 16.093 22.5355 16.0601 21.9143 15.902C21.047 15.681 20.4895 15.342 20.4895 15.342C20.4895 15.342 20.1044 15.1003 20.0732 15.0834V19.7526C20.0732 20.0125 20.002 20.6618 19.785 21.2033C19.5016 21.9117 19.0643 22.3767 18.9839 22.4717C18.9839 22.4717 18.452 23.1002 17.5138 23.5235C16.668 23.9053 15.9254 23.8956 15.7035 23.9053C15.7035 23.9053 14.4199 23.9562 13.2648 23.2055C13.015 23.04 12.7819 22.8527 12.5684 22.6458L12.5741 22.6499C13.7295 23.4005 15.0128 23.3497 15.0128 23.3497C15.2351 23.34 15.9776 23.3497 16.8231 22.9679C17.7605 22.5446 18.2932 21.9161 18.2932 21.9161C18.3728 21.8211 18.8121 21.3561 19.0943 20.6474C19.3108 20.1062 19.3826 19.4567 19.3826 19.1967V14.5281C19.4137 14.5452 19.7985 14.787 19.7985 14.787C19.7985 14.787 20.3563 15.1263 21.2237 15.347C21.8452 15.505 22.6843 15.5379 22.6843 15.5379V13.7661C22.9714 13.8305 23.2161 13.8479 23.375 13.8319Z" fill="#EE1D52"/>
                            <path d="M22.6846 13.7661V15.5374C22.6846 15.5374 21.8455 15.5045 21.224 15.3464C20.3566 15.1254 19.7988 14.7864 19.7988 14.7864C19.7988 14.7864 19.414 14.5447 19.3828 14.5276V19.1972C19.3828 19.4572 19.3116 20.1067 19.0946 20.648C18.8112 21.3566 18.3739 21.8216 18.2935 21.9167C18.2935 21.9167 17.7614 22.5452 16.8234 22.9684C15.9779 23.3503 15.2354 23.3406 15.0131 23.3503C15.0131 23.3503 13.7298 23.4011 12.5744 22.6504L12.5687 22.6463C12.4467 22.5282 12.3319 22.4035 12.2248 22.2728C11.8561 21.8233 11.6301 21.2917 11.5733 21.14C11.5732 21.1394 11.5732 21.1387 11.5733 21.1381C11.4819 20.8745 11.2899 20.2416 11.3162 19.6285C11.3626 18.5469 11.7431 17.883 11.8437 17.7166C12.1101 17.2631 12.4567 16.8573 12.8679 16.5173C13.2307 16.2239 13.642 15.9905 14.0849 15.8266C14.5637 15.6342 15.0763 15.531 15.5954 15.5227V17.3158C15.5954 17.3158 14.6459 17.0146 13.886 17.5478C13.3547 17.9424 13.0728 18.3272 12.9898 19.0146C12.9863 19.5205 13.1158 20.2363 13.8258 20.7137C13.9086 20.7662 13.9899 20.8128 14.0696 20.8535C14.1937 21.0148 14.3446 21.1552 14.5164 21.2693C15.21 21.7083 15.7911 21.739 16.5343 21.4539C17.0298 21.2632 17.4028 20.8336 17.5757 20.3576C17.6844 20.0603 17.683 19.7611 17.683 19.4517V10.6494H19.4125C19.484 11.0558 19.6818 11.6344 20.2047 12.2074C20.4144 12.4237 20.6507 12.615 20.9083 12.777C20.9844 12.8558 21.3736 13.2451 21.8731 13.484C22.1314 13.6076 22.4037 13.7022 22.6846 13.7661Z" fill="white"/>
                            <path d="M10.8849 20.5894V20.5907L10.9278 20.7071C10.9229 20.6935 10.907 20.6523 10.8849 20.5894Z" fill="#69C9D0"/>
                            <path d="M14.0849 15.8266C13.6421 15.9905 13.2308 16.2239 12.8679 16.5173C12.4566 16.858 12.1101 17.2647 11.844 17.7191C11.7434 17.8849 11.3629 18.5493 11.3165 19.631C11.2902 20.244 11.4822 20.877 11.5736 21.1406C11.5735 21.1412 11.5735 21.1419 11.5736 21.1425C11.6313 21.2928 11.8564 21.8244 12.2251 22.2752C12.3322 22.4059 12.447 22.5307 12.569 22.6488C12.1781 22.3897 11.8296 22.0765 11.5347 21.7194C11.1692 21.2737 10.9438 20.7477 10.885 20.5924C10.8849 20.5913 10.8849 20.5902 10.885 20.5891V20.5872C10.7933 20.3239 10.6007 19.6906 10.6275 19.0768C10.6739 17.9951 11.0544 17.3312 11.1551 17.1649C11.4211 16.7104 11.7675 16.3038 12.179 15.9631C12.5418 15.6696 12.9531 15.4362 13.396 15.2724C13.6723 15.1625 13.9601 15.0815 14.2544 15.0306C14.6981 14.9564 15.1511 14.95 15.5969 15.0116V15.5227C15.0773 15.5308 14.5641 15.634 14.0849 15.8266Z" fill="#69C9D0"/>
                            <path d="M19.414 10.6496H17.6844V19.4522C17.6844 19.7616 17.6844 20.06 17.5772 20.3581C17.4025 20.8338 17.0309 21.2635 16.5357 21.4541C15.7923 21.7403 15.2111 21.7085 14.5179 21.2695C14.3458 21.156 14.1944 21.0159 14.0699 20.8551C14.6606 21.1571 15.1892 21.1518 15.8442 20.8999C16.3391 20.7092 16.7112 20.2796 16.8854 19.8036C16.9943 19.5063 16.9929 19.2071 16.9929 18.898V10.0938H19.3811C19.3811 10.0938 19.3543 10.3126 19.414 10.6496ZM22.6846 13.2765V13.7663C22.4042 13.7023 22.1324 13.6077 21.8746 13.4843C21.375 13.2453 20.9859 12.856 20.9098 12.7773C20.9981 12.8328 21.0897 12.8834 21.1842 12.9287C21.7916 13.2193 22.3897 13.3061 22.6846 13.2765Z" fill="#69C9D0"/>
                            </svg>
                            </a>
                        </picture>
                    </div>
                </div>
                <h4>Linda Gaming</h4>
            </div>
            <div class="public-figure-child">
                <picture>
                    <img src="./dist/img/Rectangle 8.png" alt="">
                </picture>
                <div class="public-figure-child-info">
                    <div>
                    <h5 class="btn-show-info">Hyeonie</h5>
                    <p>V-Top Channel</p>
                    </div>
                    <ul>
                        <li>12M lượt thích trên tiktok</li>
                        <li>10M followers</li>
                        <li>1000 virual videos</li>
                    </ul>
                    <div class="socail-info">
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#3B5998"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M20.7648 12.0119C20.3233 11.9236 19.7269 11.8577 19.3519 11.8577C18.3364 11.8577 18.2704 12.2992 18.2704 13.0056V14.2632H20.8089L20.5877 16.8682H18.2704V24.7918H15.092V16.8682H13.4583V14.2632H15.092V12.6519C15.092 10.4448 16.1293 9.2085 18.7338 9.2085C19.6386 9.2085 20.3009 9.34096 21.1616 9.51757L20.7648 12.0119Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#1DA1F2"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M25.5 11.5518C24.875 11.8294 24.2024 12.0164 23.497 12.1009C24.2172 11.6691 24.7702 10.9857 25.0303 10.1715C24.3571 10.5715 23.6097 10.8611 22.8159 11.018C22.1796 10.3403 21.2724 9.9165 20.27 9.9165C18.344 9.9165 16.7824 11.4781 16.7824 13.4041C16.7824 13.6772 16.8136 13.9435 16.8731 14.1991C13.9742 14.054 11.4045 12.6652 9.68425 10.5551C9.38394 11.0702 9.21225 11.6691 9.21225 12.3082C9.21225 13.518 9.82704 14.5855 10.7637 15.2111C10.1914 15.193 9.65422 15.036 9.18335 14.7748V14.8184C9.18335 16.5087 10.3863 17.9179 11.9808 18.2392C11.6884 18.3185 11.3802 18.3615 11.0623 18.3615C10.8373 18.3615 10.6186 18.3394 10.4056 18.2986C10.8492 19.6841 12.1378 20.6927 13.6637 20.721C12.4704 21.6559 10.9665 22.2141 9.33238 22.2141C9.0502 22.2141 8.77255 22.1976 8.5 22.1648C10.0435 23.1541 11.8765 23.7321 13.8461 23.7321C20.2609 23.7321 23.7689 18.4176 23.7689 13.8092C23.7689 13.658 23.7661 13.5072 23.7588 13.3582C24.441 12.8652 25.0325 12.251 25.5 11.5518Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#C13584"/>
                            <path d="M17 10.0315C19.2696 10.0315 19.5384 10.0402 20.4347 10.0811C21.2635 10.1189 21.7135 10.2573 22.0131 10.3738C22.4098 10.528 22.693 10.7121 22.9904 11.0096C23.2878 11.307 23.472 11.5902 23.6262 11.9869C23.7426 12.2864 23.8811 12.7365 23.9189 13.5653C23.9598 14.4615 23.9685 14.7304 23.9685 17C23.9685 19.2696 23.9598 19.5384 23.9189 20.4347C23.8811 21.2634 23.7426 21.7135 23.6262 22.013C23.472 22.4098 23.2878 22.6929 22.9904 22.9903C22.693 23.2878 22.4098 23.472 22.0131 23.6262C21.7135 23.7426 21.2635 23.8811 20.4347 23.9189C19.5386 23.9597 19.2698 23.9684 17 23.9684C14.7302 23.9684 14.4615 23.9597 13.5653 23.9189C12.7365 23.8811 12.2865 23.7426 11.9869 23.6262C11.5902 23.472 11.307 23.2878 11.0096 22.9903C10.7122 22.6929 10.528 22.4098 10.3738 22.013C10.2574 21.7135 10.1189 21.2634 10.0811 20.4347C10.0402 19.5384 10.0315 19.2696 10.0315 17C10.0315 14.7304 10.0402 14.4615 10.0811 13.5653C10.1189 12.7365 10.2574 12.2864 10.3738 11.9869C10.528 11.5902 10.7121 11.307 11.0096 11.0096C11.307 10.7121 11.5902 10.528 11.9869 10.3738C12.2865 10.2573 12.7365 10.1189 13.5653 10.0811C14.4616 10.0402 14.7304 10.0315 17 10.0315ZM17 8.5C14.6915 8.5 14.4021 8.50978 13.4955 8.55115C12.5907 8.59242 11.9728 8.73612 11.4322 8.94622C10.8732 9.16344 10.3992 9.45409 9.92663 9.92662C9.45409 10.3992 9.16345 10.8732 8.94626 11.4322C8.73612 11.9728 8.59242 12.5907 8.55115 13.4954C8.50978 14.4021 8.5 14.6915 8.5 17C8.5 19.3084 8.50978 19.5979 8.55115 20.5045C8.59242 21.4092 8.73612 22.0271 8.94626 22.5678C9.16345 23.1267 9.45409 23.6007 9.92663 24.0733C10.3992 24.5459 10.8732 24.8365 11.4322 25.0537C11.9728 25.2638 12.5907 25.4075 13.4955 25.4488C14.4021 25.4902 14.6915 25.4999 17 25.4999C19.3085 25.4999 19.5979 25.4902 20.5045 25.4488C21.4093 25.4075 22.0272 25.2638 22.5678 25.0537C23.1268 24.8365 23.6008 24.5459 24.0734 24.0733C24.5459 23.6007 24.8366 23.1267 25.0538 22.5678C25.2639 22.0271 25.4076 21.4092 25.4488 20.5045C25.4902 19.5979 25.5 19.3084 25.5 17C25.5 14.6915 25.4902 14.4021 25.4488 13.4954C25.4076 12.5907 25.2639 11.9728 25.0538 11.4322C24.8366 10.8732 24.5459 10.3992 24.0734 9.92662C23.6008 9.45409 23.1268 9.16344 22.5678 8.94622C22.0272 8.73612 21.4093 8.59242 20.5045 8.55115C19.5979 8.50978 19.3085 8.5 17 8.5Z" fill="white"/>
                            <path d="M17.0039 12.6392C14.5933 12.6392 12.6391 14.5934 12.6391 17.004C12.6391 19.4147 14.5933 21.3689 17.0039 21.3689C19.4146 21.3689 21.3688 19.4147 21.3688 17.004C21.3688 14.5934 19.4146 12.6392 17.0039 12.6392ZM17.0039 19.8373C15.4391 19.8373 14.1706 18.5688 14.1706 17.004C14.1706 15.4392 15.4391 14.1707 17.0039 14.1707C18.5687 14.1707 19.8373 15.4392 19.8373 17.004C19.8373 18.5688 18.5687 19.8373 17.0039 19.8373Z" fill="white"/>
                            <path d="M22.561 12.4639C22.561 13.0272 22.1043 13.4838 21.541 13.4838C20.9777 13.4838 20.521 13.0272 20.521 12.4639C20.521 11.9005 20.9777 11.4438 21.541 11.4438C22.1043 11.4438 22.561 11.9005 22.561 12.4639Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#FF0000"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M25.0045 11.6011C25.2872 11.8838 25.4909 12.2356 25.5953 12.6216C26.1966 15.042 26.0577 18.8646 25.607 21.3784C25.5026 21.7643 25.2989 22.1162 25.0162 22.3989C24.7335 22.6816 24.3817 22.8853 23.9957 22.9897C22.583 23.375 16.8968 23.375 16.8968 23.375C16.8968 23.375 11.2107 23.375 9.79794 22.9897C9.41203 22.8853 9.0602 22.6816 8.77751 22.3989C8.49481 22.1162 8.29111 21.7643 8.18668 21.3784C7.58187 18.9685 7.74767 15.1435 8.175 12.6332C8.27943 12.2473 8.48314 11.8955 8.76583 11.6128C9.04853 11.3301 9.40035 11.1264 9.78627 11.022C11.199 10.6367 16.8852 10.625 16.8852 10.625C16.8852 10.625 22.5713 10.625 23.9841 11.0103C24.37 11.1147 24.7218 11.3184 25.0045 11.6011ZM19.7924 17L15.0754 19.7321V14.2679L19.7924 17Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#161414"/>
                            <path d="M12.9895 19.0146C13.0725 18.3272 13.3544 17.9424 13.8857 17.5478C14.6459 17.0135 15.5954 17.3158 15.5954 17.3158V15.5227C15.8262 15.5168 16.0572 15.5305 16.2855 15.5636V17.8711C16.2855 17.8711 15.3362 17.5688 14.5761 18.1034C14.0451 18.4977 13.7626 18.8828 13.6799 19.5702C13.6773 19.9435 13.7473 20.4314 14.0699 20.8533C13.9902 20.8124 13.9089 20.7658 13.826 20.7135C13.1155 20.2363 12.986 19.5205 12.9895 19.0146ZM20.2061 12.2074C19.6832 11.6344 19.4855 11.0558 19.414 10.6494H20.0718C20.0718 10.6494 19.9406 11.715 20.8965 12.763L20.9098 12.777C20.6521 12.615 20.4159 12.4237 20.2061 12.2074ZM23.375 13.8319V16.093C23.375 16.093 22.5355 16.0601 21.9143 15.902C21.047 15.681 20.4895 15.342 20.4895 15.342C20.4895 15.342 20.1044 15.1003 20.0732 15.0834V19.7526C20.0732 20.0125 20.002 20.6618 19.785 21.2033C19.5016 21.9117 19.0643 22.3767 18.9839 22.4717C18.9839 22.4717 18.452 23.1002 17.5138 23.5235C16.668 23.9053 15.9254 23.8956 15.7035 23.9053C15.7035 23.9053 14.4199 23.9562 13.2648 23.2055C13.015 23.04 12.7819 22.8527 12.5684 22.6458L12.5741 22.6499C13.7295 23.4005 15.0128 23.3497 15.0128 23.3497C15.2351 23.34 15.9776 23.3497 16.8231 22.9679C17.7605 22.5446 18.2932 21.9161 18.2932 21.9161C18.3728 21.8211 18.8121 21.3561 19.0943 20.6474C19.3108 20.1062 19.3826 19.4567 19.3826 19.1967V14.5281C19.4137 14.5452 19.7985 14.787 19.7985 14.787C19.7985 14.787 20.3563 15.1263 21.2237 15.347C21.8452 15.505 22.6843 15.5379 22.6843 15.5379V13.7661C22.9714 13.8305 23.2161 13.8479 23.375 13.8319Z" fill="#EE1D52"/>
                            <path d="M22.6846 13.7661V15.5374C22.6846 15.5374 21.8455 15.5045 21.224 15.3464C20.3566 15.1254 19.7988 14.7864 19.7988 14.7864C19.7988 14.7864 19.414 14.5447 19.3828 14.5276V19.1972C19.3828 19.4572 19.3116 20.1067 19.0946 20.648C18.8112 21.3566 18.3739 21.8216 18.2935 21.9167C18.2935 21.9167 17.7614 22.5452 16.8234 22.9684C15.9779 23.3503 15.2354 23.3406 15.0131 23.3503C15.0131 23.3503 13.7298 23.4011 12.5744 22.6504L12.5687 22.6463C12.4467 22.5282 12.3319 22.4035 12.2248 22.2728C11.8561 21.8233 11.6301 21.2917 11.5733 21.14C11.5732 21.1394 11.5732 21.1387 11.5733 21.1381C11.4819 20.8745 11.2899 20.2416 11.3162 19.6285C11.3626 18.5469 11.7431 17.883 11.8437 17.7166C12.1101 17.2631 12.4567 16.8573 12.8679 16.5173C13.2307 16.2239 13.642 15.9905 14.0849 15.8266C14.5637 15.6342 15.0763 15.531 15.5954 15.5227V17.3158C15.5954 17.3158 14.6459 17.0146 13.886 17.5478C13.3547 17.9424 13.0728 18.3272 12.9898 19.0146C12.9863 19.5205 13.1158 20.2363 13.8258 20.7137C13.9086 20.7662 13.9899 20.8128 14.0696 20.8535C14.1937 21.0148 14.3446 21.1552 14.5164 21.2693C15.21 21.7083 15.7911 21.739 16.5343 21.4539C17.0298 21.2632 17.4028 20.8336 17.5757 20.3576C17.6844 20.0603 17.683 19.7611 17.683 19.4517V10.6494H19.4125C19.484 11.0558 19.6818 11.6344 20.2047 12.2074C20.4144 12.4237 20.6507 12.615 20.9083 12.777C20.9844 12.8558 21.3736 13.2451 21.8731 13.484C22.1314 13.6076 22.4037 13.7022 22.6846 13.7661Z" fill="white"/>
                            <path d="M10.8849 20.5894V20.5907L10.9278 20.7071C10.9229 20.6935 10.907 20.6523 10.8849 20.5894Z" fill="#69C9D0"/>
                            <path d="M14.0849 15.8266C13.6421 15.9905 13.2308 16.2239 12.8679 16.5173C12.4566 16.858 12.1101 17.2647 11.844 17.7191C11.7434 17.8849 11.3629 18.5493 11.3165 19.631C11.2902 20.244 11.4822 20.877 11.5736 21.1406C11.5735 21.1412 11.5735 21.1419 11.5736 21.1425C11.6313 21.2928 11.8564 21.8244 12.2251 22.2752C12.3322 22.4059 12.447 22.5307 12.569 22.6488C12.1781 22.3897 11.8296 22.0765 11.5347 21.7194C11.1692 21.2737 10.9438 20.7477 10.885 20.5924C10.8849 20.5913 10.8849 20.5902 10.885 20.5891V20.5872C10.7933 20.3239 10.6007 19.6906 10.6275 19.0768C10.6739 17.9951 11.0544 17.3312 11.1551 17.1649C11.4211 16.7104 11.7675 16.3038 12.179 15.9631C12.5418 15.6696 12.9531 15.4362 13.396 15.2724C13.6723 15.1625 13.9601 15.0815 14.2544 15.0306C14.6981 14.9564 15.1511 14.95 15.5969 15.0116V15.5227C15.0773 15.5308 14.5641 15.634 14.0849 15.8266Z" fill="#69C9D0"/>
                            <path d="M19.414 10.6496H17.6844V19.4522C17.6844 19.7616 17.6844 20.06 17.5772 20.3581C17.4025 20.8338 17.0309 21.2635 16.5357 21.4541C15.7923 21.7403 15.2111 21.7085 14.5179 21.2695C14.3458 21.156 14.1944 21.0159 14.0699 20.8551C14.6606 21.1571 15.1892 21.1518 15.8442 20.8999C16.3391 20.7092 16.7112 20.2796 16.8854 19.8036C16.9943 19.5063 16.9929 19.2071 16.9929 18.898V10.0938H19.3811C19.3811 10.0938 19.3543 10.3126 19.414 10.6496ZM22.6846 13.2765V13.7663C22.4042 13.7023 22.1324 13.6077 21.8746 13.4843C21.375 13.2453 20.9859 12.856 20.9098 12.7773C20.9981 12.8328 21.0897 12.8834 21.1842 12.9287C21.7916 13.2193 22.3897 13.3061 22.6846 13.2765Z" fill="#69C9D0"/>
                            </svg>
                            </a>
                        </picture>
                    </div>
                </div>
                <h4>Hyeonie</h4>
            </div>
            <div class="public-figure-child">
                <picture>
                    <img src="./dist/img/Rectangle 9.png" alt="">
                </picture>
                <div class="public-figure-child-info">
                    <div>
                    <h5 class="btn-show-info">Lania</h5>
                    <p>V-Top Channel</p>
                    </div>
                    <ul>
                        <li>12M lượt thích trên tiktok</li>
                        <li>10M followers</li>
                        <li>1000 virual videos</li>
                    </ul>
                    <div class="socail-info">
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#3B5998"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M20.7648 12.0119C20.3233 11.9236 19.7269 11.8577 19.3519 11.8577C18.3364 11.8577 18.2704 12.2992 18.2704 13.0056V14.2632H20.8089L20.5877 16.8682H18.2704V24.7918H15.092V16.8682H13.4583V14.2632H15.092V12.6519C15.092 10.4448 16.1293 9.2085 18.7338 9.2085C19.6386 9.2085 20.3009 9.34096 21.1616 9.51757L20.7648 12.0119Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#1DA1F2"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M25.5 11.5518C24.875 11.8294 24.2024 12.0164 23.497 12.1009C24.2172 11.6691 24.7702 10.9857 25.0303 10.1715C24.3571 10.5715 23.6097 10.8611 22.8159 11.018C22.1796 10.3403 21.2724 9.9165 20.27 9.9165C18.344 9.9165 16.7824 11.4781 16.7824 13.4041C16.7824 13.6772 16.8136 13.9435 16.8731 14.1991C13.9742 14.054 11.4045 12.6652 9.68425 10.5551C9.38394 11.0702 9.21225 11.6691 9.21225 12.3082C9.21225 13.518 9.82704 14.5855 10.7637 15.2111C10.1914 15.193 9.65422 15.036 9.18335 14.7748V14.8184C9.18335 16.5087 10.3863 17.9179 11.9808 18.2392C11.6884 18.3185 11.3802 18.3615 11.0623 18.3615C10.8373 18.3615 10.6186 18.3394 10.4056 18.2986C10.8492 19.6841 12.1378 20.6927 13.6637 20.721C12.4704 21.6559 10.9665 22.2141 9.33238 22.2141C9.0502 22.2141 8.77255 22.1976 8.5 22.1648C10.0435 23.1541 11.8765 23.7321 13.8461 23.7321C20.2609 23.7321 23.7689 18.4176 23.7689 13.8092C23.7689 13.658 23.7661 13.5072 23.7588 13.3582C24.441 12.8652 25.0325 12.251 25.5 11.5518Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#C13584"/>
                            <path d="M17 10.0315C19.2696 10.0315 19.5384 10.0402 20.4347 10.0811C21.2635 10.1189 21.7135 10.2573 22.0131 10.3738C22.4098 10.528 22.693 10.7121 22.9904 11.0096C23.2878 11.307 23.472 11.5902 23.6262 11.9869C23.7426 12.2864 23.8811 12.7365 23.9189 13.5653C23.9598 14.4615 23.9685 14.7304 23.9685 17C23.9685 19.2696 23.9598 19.5384 23.9189 20.4347C23.8811 21.2634 23.7426 21.7135 23.6262 22.013C23.472 22.4098 23.2878 22.6929 22.9904 22.9903C22.693 23.2878 22.4098 23.472 22.0131 23.6262C21.7135 23.7426 21.2635 23.8811 20.4347 23.9189C19.5386 23.9597 19.2698 23.9684 17 23.9684C14.7302 23.9684 14.4615 23.9597 13.5653 23.9189C12.7365 23.8811 12.2865 23.7426 11.9869 23.6262C11.5902 23.472 11.307 23.2878 11.0096 22.9903C10.7122 22.6929 10.528 22.4098 10.3738 22.013C10.2574 21.7135 10.1189 21.2634 10.0811 20.4347C10.0402 19.5384 10.0315 19.2696 10.0315 17C10.0315 14.7304 10.0402 14.4615 10.0811 13.5653C10.1189 12.7365 10.2574 12.2864 10.3738 11.9869C10.528 11.5902 10.7121 11.307 11.0096 11.0096C11.307 10.7121 11.5902 10.528 11.9869 10.3738C12.2865 10.2573 12.7365 10.1189 13.5653 10.0811C14.4616 10.0402 14.7304 10.0315 17 10.0315ZM17 8.5C14.6915 8.5 14.4021 8.50978 13.4955 8.55115C12.5907 8.59242 11.9728 8.73612 11.4322 8.94622C10.8732 9.16344 10.3992 9.45409 9.92663 9.92662C9.45409 10.3992 9.16345 10.8732 8.94626 11.4322C8.73612 11.9728 8.59242 12.5907 8.55115 13.4954C8.50978 14.4021 8.5 14.6915 8.5 17C8.5 19.3084 8.50978 19.5979 8.55115 20.5045C8.59242 21.4092 8.73612 22.0271 8.94626 22.5678C9.16345 23.1267 9.45409 23.6007 9.92663 24.0733C10.3992 24.5459 10.8732 24.8365 11.4322 25.0537C11.9728 25.2638 12.5907 25.4075 13.4955 25.4488C14.4021 25.4902 14.6915 25.4999 17 25.4999C19.3085 25.4999 19.5979 25.4902 20.5045 25.4488C21.4093 25.4075 22.0272 25.2638 22.5678 25.0537C23.1268 24.8365 23.6008 24.5459 24.0734 24.0733C24.5459 23.6007 24.8366 23.1267 25.0538 22.5678C25.2639 22.0271 25.4076 21.4092 25.4488 20.5045C25.4902 19.5979 25.5 19.3084 25.5 17C25.5 14.6915 25.4902 14.4021 25.4488 13.4954C25.4076 12.5907 25.2639 11.9728 25.0538 11.4322C24.8366 10.8732 24.5459 10.3992 24.0734 9.92662C23.6008 9.45409 23.1268 9.16344 22.5678 8.94622C22.0272 8.73612 21.4093 8.59242 20.5045 8.55115C19.5979 8.50978 19.3085 8.5 17 8.5Z" fill="white"/>
                            <path d="M17.0039 12.6392C14.5933 12.6392 12.6391 14.5934 12.6391 17.004C12.6391 19.4147 14.5933 21.3689 17.0039 21.3689C19.4146 21.3689 21.3688 19.4147 21.3688 17.004C21.3688 14.5934 19.4146 12.6392 17.0039 12.6392ZM17.0039 19.8373C15.4391 19.8373 14.1706 18.5688 14.1706 17.004C14.1706 15.4392 15.4391 14.1707 17.0039 14.1707C18.5687 14.1707 19.8373 15.4392 19.8373 17.004C19.8373 18.5688 18.5687 19.8373 17.0039 19.8373Z" fill="white"/>
                            <path d="M22.561 12.4639C22.561 13.0272 22.1043 13.4838 21.541 13.4838C20.9777 13.4838 20.521 13.0272 20.521 12.4639C20.521 11.9005 20.9777 11.4438 21.541 11.4438C22.1043 11.4438 22.561 11.9005 22.561 12.4639Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#FF0000"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M25.0045 11.6011C25.2872 11.8838 25.4909 12.2356 25.5953 12.6216C26.1966 15.042 26.0577 18.8646 25.607 21.3784C25.5026 21.7643 25.2989 22.1162 25.0162 22.3989C24.7335 22.6816 24.3817 22.8853 23.9957 22.9897C22.583 23.375 16.8968 23.375 16.8968 23.375C16.8968 23.375 11.2107 23.375 9.79794 22.9897C9.41203 22.8853 9.0602 22.6816 8.77751 22.3989C8.49481 22.1162 8.29111 21.7643 8.18668 21.3784C7.58187 18.9685 7.74767 15.1435 8.175 12.6332C8.27943 12.2473 8.48314 11.8955 8.76583 11.6128C9.04853 11.3301 9.40035 11.1264 9.78627 11.022C11.199 10.6367 16.8852 10.625 16.8852 10.625C16.8852 10.625 22.5713 10.625 23.9841 11.0103C24.37 11.1147 24.7218 11.3184 25.0045 11.6011ZM19.7924 17L15.0754 19.7321V14.2679L19.7924 17Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#161414"/>
                            <path d="M12.9895 19.0146C13.0725 18.3272 13.3544 17.9424 13.8857 17.5478C14.6459 17.0135 15.5954 17.3158 15.5954 17.3158V15.5227C15.8262 15.5168 16.0572 15.5305 16.2855 15.5636V17.8711C16.2855 17.8711 15.3362 17.5688 14.5761 18.1034C14.0451 18.4977 13.7626 18.8828 13.6799 19.5702C13.6773 19.9435 13.7473 20.4314 14.0699 20.8533C13.9902 20.8124 13.9089 20.7658 13.826 20.7135C13.1155 20.2363 12.986 19.5205 12.9895 19.0146ZM20.2061 12.2074C19.6832 11.6344 19.4855 11.0558 19.414 10.6494H20.0718C20.0718 10.6494 19.9406 11.715 20.8965 12.763L20.9098 12.777C20.6521 12.615 20.4159 12.4237 20.2061 12.2074ZM23.375 13.8319V16.093C23.375 16.093 22.5355 16.0601 21.9143 15.902C21.047 15.681 20.4895 15.342 20.4895 15.342C20.4895 15.342 20.1044 15.1003 20.0732 15.0834V19.7526C20.0732 20.0125 20.002 20.6618 19.785 21.2033C19.5016 21.9117 19.0643 22.3767 18.9839 22.4717C18.9839 22.4717 18.452 23.1002 17.5138 23.5235C16.668 23.9053 15.9254 23.8956 15.7035 23.9053C15.7035 23.9053 14.4199 23.9562 13.2648 23.2055C13.015 23.04 12.7819 22.8527 12.5684 22.6458L12.5741 22.6499C13.7295 23.4005 15.0128 23.3497 15.0128 23.3497C15.2351 23.34 15.9776 23.3497 16.8231 22.9679C17.7605 22.5446 18.2932 21.9161 18.2932 21.9161C18.3728 21.8211 18.8121 21.3561 19.0943 20.6474C19.3108 20.1062 19.3826 19.4567 19.3826 19.1967V14.5281C19.4137 14.5452 19.7985 14.787 19.7985 14.787C19.7985 14.787 20.3563 15.1263 21.2237 15.347C21.8452 15.505 22.6843 15.5379 22.6843 15.5379V13.7661C22.9714 13.8305 23.2161 13.8479 23.375 13.8319Z" fill="#EE1D52"/>
                            <path d="M22.6846 13.7661V15.5374C22.6846 15.5374 21.8455 15.5045 21.224 15.3464C20.3566 15.1254 19.7988 14.7864 19.7988 14.7864C19.7988 14.7864 19.414 14.5447 19.3828 14.5276V19.1972C19.3828 19.4572 19.3116 20.1067 19.0946 20.648C18.8112 21.3566 18.3739 21.8216 18.2935 21.9167C18.2935 21.9167 17.7614 22.5452 16.8234 22.9684C15.9779 23.3503 15.2354 23.3406 15.0131 23.3503C15.0131 23.3503 13.7298 23.4011 12.5744 22.6504L12.5687 22.6463C12.4467 22.5282 12.3319 22.4035 12.2248 22.2728C11.8561 21.8233 11.6301 21.2917 11.5733 21.14C11.5732 21.1394 11.5732 21.1387 11.5733 21.1381C11.4819 20.8745 11.2899 20.2416 11.3162 19.6285C11.3626 18.5469 11.7431 17.883 11.8437 17.7166C12.1101 17.2631 12.4567 16.8573 12.8679 16.5173C13.2307 16.2239 13.642 15.9905 14.0849 15.8266C14.5637 15.6342 15.0763 15.531 15.5954 15.5227V17.3158C15.5954 17.3158 14.6459 17.0146 13.886 17.5478C13.3547 17.9424 13.0728 18.3272 12.9898 19.0146C12.9863 19.5205 13.1158 20.2363 13.8258 20.7137C13.9086 20.7662 13.9899 20.8128 14.0696 20.8535C14.1937 21.0148 14.3446 21.1552 14.5164 21.2693C15.21 21.7083 15.7911 21.739 16.5343 21.4539C17.0298 21.2632 17.4028 20.8336 17.5757 20.3576C17.6844 20.0603 17.683 19.7611 17.683 19.4517V10.6494H19.4125C19.484 11.0558 19.6818 11.6344 20.2047 12.2074C20.4144 12.4237 20.6507 12.615 20.9083 12.777C20.9844 12.8558 21.3736 13.2451 21.8731 13.484C22.1314 13.6076 22.4037 13.7022 22.6846 13.7661Z" fill="white"/>
                            <path d="M10.8849 20.5894V20.5907L10.9278 20.7071C10.9229 20.6935 10.907 20.6523 10.8849 20.5894Z" fill="#69C9D0"/>
                            <path d="M14.0849 15.8266C13.6421 15.9905 13.2308 16.2239 12.8679 16.5173C12.4566 16.858 12.1101 17.2647 11.844 17.7191C11.7434 17.8849 11.3629 18.5493 11.3165 19.631C11.2902 20.244 11.4822 20.877 11.5736 21.1406C11.5735 21.1412 11.5735 21.1419 11.5736 21.1425C11.6313 21.2928 11.8564 21.8244 12.2251 22.2752C12.3322 22.4059 12.447 22.5307 12.569 22.6488C12.1781 22.3897 11.8296 22.0765 11.5347 21.7194C11.1692 21.2737 10.9438 20.7477 10.885 20.5924C10.8849 20.5913 10.8849 20.5902 10.885 20.5891V20.5872C10.7933 20.3239 10.6007 19.6906 10.6275 19.0768C10.6739 17.9951 11.0544 17.3312 11.1551 17.1649C11.4211 16.7104 11.7675 16.3038 12.179 15.9631C12.5418 15.6696 12.9531 15.4362 13.396 15.2724C13.6723 15.1625 13.9601 15.0815 14.2544 15.0306C14.6981 14.9564 15.1511 14.95 15.5969 15.0116V15.5227C15.0773 15.5308 14.5641 15.634 14.0849 15.8266Z" fill="#69C9D0"/>
                            <path d="M19.414 10.6496H17.6844V19.4522C17.6844 19.7616 17.6844 20.06 17.5772 20.3581C17.4025 20.8338 17.0309 21.2635 16.5357 21.4541C15.7923 21.7403 15.2111 21.7085 14.5179 21.2695C14.3458 21.156 14.1944 21.0159 14.0699 20.8551C14.6606 21.1571 15.1892 21.1518 15.8442 20.8999C16.3391 20.7092 16.7112 20.2796 16.8854 19.8036C16.9943 19.5063 16.9929 19.2071 16.9929 18.898V10.0938H19.3811C19.3811 10.0938 19.3543 10.3126 19.414 10.6496ZM22.6846 13.2765V13.7663C22.4042 13.7023 22.1324 13.6077 21.8746 13.4843C21.375 13.2453 20.9859 12.856 20.9098 12.7773C20.9981 12.8328 21.0897 12.8834 21.1842 12.9287C21.7916 13.2193 22.3897 13.3061 22.6846 13.2765Z" fill="#69C9D0"/>
                            </svg>
                            </a>
                        </picture>
                    </div>
                </div>
                <h4>Lania</h4>
            </div>
            <div class="public-figure-child">
                <picture>
                    <img src="./dist/img/Rectangle 10.png" alt="">
                </picture>
                <div class="public-figure-child-info">
                    <div>
                    <h5 class="btn-show-info">Hoàng Touliver</h5>
                    <p>V-Top Channel</p>
                    </div>
                    <ul>
                        <li>12M lượt thích trên tiktok</li>
                        <li>10M followers</li>
                        <li>1000 virual videos</li>
                    </ul>
                    <div class="socail-info">
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#3B5998"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M20.7648 12.0119C20.3233 11.9236 19.7269 11.8577 19.3519 11.8577C18.3364 11.8577 18.2704 12.2992 18.2704 13.0056V14.2632H20.8089L20.5877 16.8682H18.2704V24.7918H15.092V16.8682H13.4583V14.2632H15.092V12.6519C15.092 10.4448 16.1293 9.2085 18.7338 9.2085C19.6386 9.2085 20.3009 9.34096 21.1616 9.51757L20.7648 12.0119Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#1DA1F2"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M25.5 11.5518C24.875 11.8294 24.2024 12.0164 23.497 12.1009C24.2172 11.6691 24.7702 10.9857 25.0303 10.1715C24.3571 10.5715 23.6097 10.8611 22.8159 11.018C22.1796 10.3403 21.2724 9.9165 20.27 9.9165C18.344 9.9165 16.7824 11.4781 16.7824 13.4041C16.7824 13.6772 16.8136 13.9435 16.8731 14.1991C13.9742 14.054 11.4045 12.6652 9.68425 10.5551C9.38394 11.0702 9.21225 11.6691 9.21225 12.3082C9.21225 13.518 9.82704 14.5855 10.7637 15.2111C10.1914 15.193 9.65422 15.036 9.18335 14.7748V14.8184C9.18335 16.5087 10.3863 17.9179 11.9808 18.2392C11.6884 18.3185 11.3802 18.3615 11.0623 18.3615C10.8373 18.3615 10.6186 18.3394 10.4056 18.2986C10.8492 19.6841 12.1378 20.6927 13.6637 20.721C12.4704 21.6559 10.9665 22.2141 9.33238 22.2141C9.0502 22.2141 8.77255 22.1976 8.5 22.1648C10.0435 23.1541 11.8765 23.7321 13.8461 23.7321C20.2609 23.7321 23.7689 18.4176 23.7689 13.8092C23.7689 13.658 23.7661 13.5072 23.7588 13.3582C24.441 12.8652 25.0325 12.251 25.5 11.5518Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#C13584"/>
                            <path d="M17 10.0315C19.2696 10.0315 19.5384 10.0402 20.4347 10.0811C21.2635 10.1189 21.7135 10.2573 22.0131 10.3738C22.4098 10.528 22.693 10.7121 22.9904 11.0096C23.2878 11.307 23.472 11.5902 23.6262 11.9869C23.7426 12.2864 23.8811 12.7365 23.9189 13.5653C23.9598 14.4615 23.9685 14.7304 23.9685 17C23.9685 19.2696 23.9598 19.5384 23.9189 20.4347C23.8811 21.2634 23.7426 21.7135 23.6262 22.013C23.472 22.4098 23.2878 22.6929 22.9904 22.9903C22.693 23.2878 22.4098 23.472 22.0131 23.6262C21.7135 23.7426 21.2635 23.8811 20.4347 23.9189C19.5386 23.9597 19.2698 23.9684 17 23.9684C14.7302 23.9684 14.4615 23.9597 13.5653 23.9189C12.7365 23.8811 12.2865 23.7426 11.9869 23.6262C11.5902 23.472 11.307 23.2878 11.0096 22.9903C10.7122 22.6929 10.528 22.4098 10.3738 22.013C10.2574 21.7135 10.1189 21.2634 10.0811 20.4347C10.0402 19.5384 10.0315 19.2696 10.0315 17C10.0315 14.7304 10.0402 14.4615 10.0811 13.5653C10.1189 12.7365 10.2574 12.2864 10.3738 11.9869C10.528 11.5902 10.7121 11.307 11.0096 11.0096C11.307 10.7121 11.5902 10.528 11.9869 10.3738C12.2865 10.2573 12.7365 10.1189 13.5653 10.0811C14.4616 10.0402 14.7304 10.0315 17 10.0315ZM17 8.5C14.6915 8.5 14.4021 8.50978 13.4955 8.55115C12.5907 8.59242 11.9728 8.73612 11.4322 8.94622C10.8732 9.16344 10.3992 9.45409 9.92663 9.92662C9.45409 10.3992 9.16345 10.8732 8.94626 11.4322C8.73612 11.9728 8.59242 12.5907 8.55115 13.4954C8.50978 14.4021 8.5 14.6915 8.5 17C8.5 19.3084 8.50978 19.5979 8.55115 20.5045C8.59242 21.4092 8.73612 22.0271 8.94626 22.5678C9.16345 23.1267 9.45409 23.6007 9.92663 24.0733C10.3992 24.5459 10.8732 24.8365 11.4322 25.0537C11.9728 25.2638 12.5907 25.4075 13.4955 25.4488C14.4021 25.4902 14.6915 25.4999 17 25.4999C19.3085 25.4999 19.5979 25.4902 20.5045 25.4488C21.4093 25.4075 22.0272 25.2638 22.5678 25.0537C23.1268 24.8365 23.6008 24.5459 24.0734 24.0733C24.5459 23.6007 24.8366 23.1267 25.0538 22.5678C25.2639 22.0271 25.4076 21.4092 25.4488 20.5045C25.4902 19.5979 25.5 19.3084 25.5 17C25.5 14.6915 25.4902 14.4021 25.4488 13.4954C25.4076 12.5907 25.2639 11.9728 25.0538 11.4322C24.8366 10.8732 24.5459 10.3992 24.0734 9.92662C23.6008 9.45409 23.1268 9.16344 22.5678 8.94622C22.0272 8.73612 21.4093 8.59242 20.5045 8.55115C19.5979 8.50978 19.3085 8.5 17 8.5Z" fill="white"/>
                            <path d="M17.0039 12.6392C14.5933 12.6392 12.6391 14.5934 12.6391 17.004C12.6391 19.4147 14.5933 21.3689 17.0039 21.3689C19.4146 21.3689 21.3688 19.4147 21.3688 17.004C21.3688 14.5934 19.4146 12.6392 17.0039 12.6392ZM17.0039 19.8373C15.4391 19.8373 14.1706 18.5688 14.1706 17.004C14.1706 15.4392 15.4391 14.1707 17.0039 14.1707C18.5687 14.1707 19.8373 15.4392 19.8373 17.004C19.8373 18.5688 18.5687 19.8373 17.0039 19.8373Z" fill="white"/>
                            <path d="M22.561 12.4639C22.561 13.0272 22.1043 13.4838 21.541 13.4838C20.9777 13.4838 20.521 13.0272 20.521 12.4639C20.521 11.9005 20.9777 11.4438 21.541 11.4438C22.1043 11.4438 22.561 11.9005 22.561 12.4639Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#FF0000"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M25.0045 11.6011C25.2872 11.8838 25.4909 12.2356 25.5953 12.6216C26.1966 15.042 26.0577 18.8646 25.607 21.3784C25.5026 21.7643 25.2989 22.1162 25.0162 22.3989C24.7335 22.6816 24.3817 22.8853 23.9957 22.9897C22.583 23.375 16.8968 23.375 16.8968 23.375C16.8968 23.375 11.2107 23.375 9.79794 22.9897C9.41203 22.8853 9.0602 22.6816 8.77751 22.3989C8.49481 22.1162 8.29111 21.7643 8.18668 21.3784C7.58187 18.9685 7.74767 15.1435 8.175 12.6332C8.27943 12.2473 8.48314 11.8955 8.76583 11.6128C9.04853 11.3301 9.40035 11.1264 9.78627 11.022C11.199 10.6367 16.8852 10.625 16.8852 10.625C16.8852 10.625 22.5713 10.625 23.9841 11.0103C24.37 11.1147 24.7218 11.3184 25.0045 11.6011ZM19.7924 17L15.0754 19.7321V14.2679L19.7924 17Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#161414"/>
                            <path d="M12.9895 19.0146C13.0725 18.3272 13.3544 17.9424 13.8857 17.5478C14.6459 17.0135 15.5954 17.3158 15.5954 17.3158V15.5227C15.8262 15.5168 16.0572 15.5305 16.2855 15.5636V17.8711C16.2855 17.8711 15.3362 17.5688 14.5761 18.1034C14.0451 18.4977 13.7626 18.8828 13.6799 19.5702C13.6773 19.9435 13.7473 20.4314 14.0699 20.8533C13.9902 20.8124 13.9089 20.7658 13.826 20.7135C13.1155 20.2363 12.986 19.5205 12.9895 19.0146ZM20.2061 12.2074C19.6832 11.6344 19.4855 11.0558 19.414 10.6494H20.0718C20.0718 10.6494 19.9406 11.715 20.8965 12.763L20.9098 12.777C20.6521 12.615 20.4159 12.4237 20.2061 12.2074ZM23.375 13.8319V16.093C23.375 16.093 22.5355 16.0601 21.9143 15.902C21.047 15.681 20.4895 15.342 20.4895 15.342C20.4895 15.342 20.1044 15.1003 20.0732 15.0834V19.7526C20.0732 20.0125 20.002 20.6618 19.785 21.2033C19.5016 21.9117 19.0643 22.3767 18.9839 22.4717C18.9839 22.4717 18.452 23.1002 17.5138 23.5235C16.668 23.9053 15.9254 23.8956 15.7035 23.9053C15.7035 23.9053 14.4199 23.9562 13.2648 23.2055C13.015 23.04 12.7819 22.8527 12.5684 22.6458L12.5741 22.6499C13.7295 23.4005 15.0128 23.3497 15.0128 23.3497C15.2351 23.34 15.9776 23.3497 16.8231 22.9679C17.7605 22.5446 18.2932 21.9161 18.2932 21.9161C18.3728 21.8211 18.8121 21.3561 19.0943 20.6474C19.3108 20.1062 19.3826 19.4567 19.3826 19.1967V14.5281C19.4137 14.5452 19.7985 14.787 19.7985 14.787C19.7985 14.787 20.3563 15.1263 21.2237 15.347C21.8452 15.505 22.6843 15.5379 22.6843 15.5379V13.7661C22.9714 13.8305 23.2161 13.8479 23.375 13.8319Z" fill="#EE1D52"/>
                            <path d="M22.6846 13.7661V15.5374C22.6846 15.5374 21.8455 15.5045 21.224 15.3464C20.3566 15.1254 19.7988 14.7864 19.7988 14.7864C19.7988 14.7864 19.414 14.5447 19.3828 14.5276V19.1972C19.3828 19.4572 19.3116 20.1067 19.0946 20.648C18.8112 21.3566 18.3739 21.8216 18.2935 21.9167C18.2935 21.9167 17.7614 22.5452 16.8234 22.9684C15.9779 23.3503 15.2354 23.3406 15.0131 23.3503C15.0131 23.3503 13.7298 23.4011 12.5744 22.6504L12.5687 22.6463C12.4467 22.5282 12.3319 22.4035 12.2248 22.2728C11.8561 21.8233 11.6301 21.2917 11.5733 21.14C11.5732 21.1394 11.5732 21.1387 11.5733 21.1381C11.4819 20.8745 11.2899 20.2416 11.3162 19.6285C11.3626 18.5469 11.7431 17.883 11.8437 17.7166C12.1101 17.2631 12.4567 16.8573 12.8679 16.5173C13.2307 16.2239 13.642 15.9905 14.0849 15.8266C14.5637 15.6342 15.0763 15.531 15.5954 15.5227V17.3158C15.5954 17.3158 14.6459 17.0146 13.886 17.5478C13.3547 17.9424 13.0728 18.3272 12.9898 19.0146C12.9863 19.5205 13.1158 20.2363 13.8258 20.7137C13.9086 20.7662 13.9899 20.8128 14.0696 20.8535C14.1937 21.0148 14.3446 21.1552 14.5164 21.2693C15.21 21.7083 15.7911 21.739 16.5343 21.4539C17.0298 21.2632 17.4028 20.8336 17.5757 20.3576C17.6844 20.0603 17.683 19.7611 17.683 19.4517V10.6494H19.4125C19.484 11.0558 19.6818 11.6344 20.2047 12.2074C20.4144 12.4237 20.6507 12.615 20.9083 12.777C20.9844 12.8558 21.3736 13.2451 21.8731 13.484C22.1314 13.6076 22.4037 13.7022 22.6846 13.7661Z" fill="white"/>
                            <path d="M10.8849 20.5894V20.5907L10.9278 20.7071C10.9229 20.6935 10.907 20.6523 10.8849 20.5894Z" fill="#69C9D0"/>
                            <path d="M14.0849 15.8266C13.6421 15.9905 13.2308 16.2239 12.8679 16.5173C12.4566 16.858 12.1101 17.2647 11.844 17.7191C11.7434 17.8849 11.3629 18.5493 11.3165 19.631C11.2902 20.244 11.4822 20.877 11.5736 21.1406C11.5735 21.1412 11.5735 21.1419 11.5736 21.1425C11.6313 21.2928 11.8564 21.8244 12.2251 22.2752C12.3322 22.4059 12.447 22.5307 12.569 22.6488C12.1781 22.3897 11.8296 22.0765 11.5347 21.7194C11.1692 21.2737 10.9438 20.7477 10.885 20.5924C10.8849 20.5913 10.8849 20.5902 10.885 20.5891V20.5872C10.7933 20.3239 10.6007 19.6906 10.6275 19.0768C10.6739 17.9951 11.0544 17.3312 11.1551 17.1649C11.4211 16.7104 11.7675 16.3038 12.179 15.9631C12.5418 15.6696 12.9531 15.4362 13.396 15.2724C13.6723 15.1625 13.9601 15.0815 14.2544 15.0306C14.6981 14.9564 15.1511 14.95 15.5969 15.0116V15.5227C15.0773 15.5308 14.5641 15.634 14.0849 15.8266Z" fill="#69C9D0"/>
                            <path d="M19.414 10.6496H17.6844V19.4522C17.6844 19.7616 17.6844 20.06 17.5772 20.3581C17.4025 20.8338 17.0309 21.2635 16.5357 21.4541C15.7923 21.7403 15.2111 21.7085 14.5179 21.2695C14.3458 21.156 14.1944 21.0159 14.0699 20.8551C14.6606 21.1571 15.1892 21.1518 15.8442 20.8999C16.3391 20.7092 16.7112 20.2796 16.8854 19.8036C16.9943 19.5063 16.9929 19.2071 16.9929 18.898V10.0938H19.3811C19.3811 10.0938 19.3543 10.3126 19.414 10.6496ZM22.6846 13.2765V13.7663C22.4042 13.7023 22.1324 13.6077 21.8746 13.4843C21.375 13.2453 20.9859 12.856 20.9098 12.7773C20.9981 12.8328 21.0897 12.8834 21.1842 12.9287C21.7916 13.2193 22.3897 13.3061 22.6846 13.2765Z" fill="#69C9D0"/>
                            </svg>
                            </a>
                        </picture>
                    </div>
                </div>
                <h4>Hoàng Touliver</h4>
            </div>
            <div class="public-figure-child">
                <picture>
                    <img src="./dist/img/Rectangle 11.png" alt="">
                </picture>
                <div class="public-figure-child-info">
                    <div>
                    <h5 class="btn-show-info">Hanna Lê</h5>
                    <p>V-Top Channel</p>
                    </div>
                    <ul>
                        <li>12M lượt thích trên tiktok</li>
                        <li>10M followers</li>
                        <li>1000 virual videos</li>
                    </ul>
                    <div class="socail-info">
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#3B5998"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M20.7648 12.0119C20.3233 11.9236 19.7269 11.8577 19.3519 11.8577C18.3364 11.8577 18.2704 12.2992 18.2704 13.0056V14.2632H20.8089L20.5877 16.8682H18.2704V24.7918H15.092V16.8682H13.4583V14.2632H15.092V12.6519C15.092 10.4448 16.1293 9.2085 18.7338 9.2085C19.6386 9.2085 20.3009 9.34096 21.1616 9.51757L20.7648 12.0119Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#1DA1F2"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M25.5 11.5518C24.875 11.8294 24.2024 12.0164 23.497 12.1009C24.2172 11.6691 24.7702 10.9857 25.0303 10.1715C24.3571 10.5715 23.6097 10.8611 22.8159 11.018C22.1796 10.3403 21.2724 9.9165 20.27 9.9165C18.344 9.9165 16.7824 11.4781 16.7824 13.4041C16.7824 13.6772 16.8136 13.9435 16.8731 14.1991C13.9742 14.054 11.4045 12.6652 9.68425 10.5551C9.38394 11.0702 9.21225 11.6691 9.21225 12.3082C9.21225 13.518 9.82704 14.5855 10.7637 15.2111C10.1914 15.193 9.65422 15.036 9.18335 14.7748V14.8184C9.18335 16.5087 10.3863 17.9179 11.9808 18.2392C11.6884 18.3185 11.3802 18.3615 11.0623 18.3615C10.8373 18.3615 10.6186 18.3394 10.4056 18.2986C10.8492 19.6841 12.1378 20.6927 13.6637 20.721C12.4704 21.6559 10.9665 22.2141 9.33238 22.2141C9.0502 22.2141 8.77255 22.1976 8.5 22.1648C10.0435 23.1541 11.8765 23.7321 13.8461 23.7321C20.2609 23.7321 23.7689 18.4176 23.7689 13.8092C23.7689 13.658 23.7661 13.5072 23.7588 13.3582C24.441 12.8652 25.0325 12.251 25.5 11.5518Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#C13584"/>
                            <path d="M17 10.0315C19.2696 10.0315 19.5384 10.0402 20.4347 10.0811C21.2635 10.1189 21.7135 10.2573 22.0131 10.3738C22.4098 10.528 22.693 10.7121 22.9904 11.0096C23.2878 11.307 23.472 11.5902 23.6262 11.9869C23.7426 12.2864 23.8811 12.7365 23.9189 13.5653C23.9598 14.4615 23.9685 14.7304 23.9685 17C23.9685 19.2696 23.9598 19.5384 23.9189 20.4347C23.8811 21.2634 23.7426 21.7135 23.6262 22.013C23.472 22.4098 23.2878 22.6929 22.9904 22.9903C22.693 23.2878 22.4098 23.472 22.0131 23.6262C21.7135 23.7426 21.2635 23.8811 20.4347 23.9189C19.5386 23.9597 19.2698 23.9684 17 23.9684C14.7302 23.9684 14.4615 23.9597 13.5653 23.9189C12.7365 23.8811 12.2865 23.7426 11.9869 23.6262C11.5902 23.472 11.307 23.2878 11.0096 22.9903C10.7122 22.6929 10.528 22.4098 10.3738 22.013C10.2574 21.7135 10.1189 21.2634 10.0811 20.4347C10.0402 19.5384 10.0315 19.2696 10.0315 17C10.0315 14.7304 10.0402 14.4615 10.0811 13.5653C10.1189 12.7365 10.2574 12.2864 10.3738 11.9869C10.528 11.5902 10.7121 11.307 11.0096 11.0096C11.307 10.7121 11.5902 10.528 11.9869 10.3738C12.2865 10.2573 12.7365 10.1189 13.5653 10.0811C14.4616 10.0402 14.7304 10.0315 17 10.0315ZM17 8.5C14.6915 8.5 14.4021 8.50978 13.4955 8.55115C12.5907 8.59242 11.9728 8.73612 11.4322 8.94622C10.8732 9.16344 10.3992 9.45409 9.92663 9.92662C9.45409 10.3992 9.16345 10.8732 8.94626 11.4322C8.73612 11.9728 8.59242 12.5907 8.55115 13.4954C8.50978 14.4021 8.5 14.6915 8.5 17C8.5 19.3084 8.50978 19.5979 8.55115 20.5045C8.59242 21.4092 8.73612 22.0271 8.94626 22.5678C9.16345 23.1267 9.45409 23.6007 9.92663 24.0733C10.3992 24.5459 10.8732 24.8365 11.4322 25.0537C11.9728 25.2638 12.5907 25.4075 13.4955 25.4488C14.4021 25.4902 14.6915 25.4999 17 25.4999C19.3085 25.4999 19.5979 25.4902 20.5045 25.4488C21.4093 25.4075 22.0272 25.2638 22.5678 25.0537C23.1268 24.8365 23.6008 24.5459 24.0734 24.0733C24.5459 23.6007 24.8366 23.1267 25.0538 22.5678C25.2639 22.0271 25.4076 21.4092 25.4488 20.5045C25.4902 19.5979 25.5 19.3084 25.5 17C25.5 14.6915 25.4902 14.4021 25.4488 13.4954C25.4076 12.5907 25.2639 11.9728 25.0538 11.4322C24.8366 10.8732 24.5459 10.3992 24.0734 9.92662C23.6008 9.45409 23.1268 9.16344 22.5678 8.94622C22.0272 8.73612 21.4093 8.59242 20.5045 8.55115C19.5979 8.50978 19.3085 8.5 17 8.5Z" fill="white"/>
                            <path d="M17.0039 12.6392C14.5933 12.6392 12.6391 14.5934 12.6391 17.004C12.6391 19.4147 14.5933 21.3689 17.0039 21.3689C19.4146 21.3689 21.3688 19.4147 21.3688 17.004C21.3688 14.5934 19.4146 12.6392 17.0039 12.6392ZM17.0039 19.8373C15.4391 19.8373 14.1706 18.5688 14.1706 17.004C14.1706 15.4392 15.4391 14.1707 17.0039 14.1707C18.5687 14.1707 19.8373 15.4392 19.8373 17.004C19.8373 18.5688 18.5687 19.8373 17.0039 19.8373Z" fill="white"/>
                            <path d="M22.561 12.4639C22.561 13.0272 22.1043 13.4838 21.541 13.4838C20.9777 13.4838 20.521 13.0272 20.521 12.4639C20.521 11.9005 20.9777 11.4438 21.541 11.4438C22.1043 11.4438 22.561 11.9005 22.561 12.4639Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#FF0000"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M25.0045 11.6011C25.2872 11.8838 25.4909 12.2356 25.5953 12.6216C26.1966 15.042 26.0577 18.8646 25.607 21.3784C25.5026 21.7643 25.2989 22.1162 25.0162 22.3989C24.7335 22.6816 24.3817 22.8853 23.9957 22.9897C22.583 23.375 16.8968 23.375 16.8968 23.375C16.8968 23.375 11.2107 23.375 9.79794 22.9897C9.41203 22.8853 9.0602 22.6816 8.77751 22.3989C8.49481 22.1162 8.29111 21.7643 8.18668 21.3784C7.58187 18.9685 7.74767 15.1435 8.175 12.6332C8.27943 12.2473 8.48314 11.8955 8.76583 11.6128C9.04853 11.3301 9.40035 11.1264 9.78627 11.022C11.199 10.6367 16.8852 10.625 16.8852 10.625C16.8852 10.625 22.5713 10.625 23.9841 11.0103C24.37 11.1147 24.7218 11.3184 25.0045 11.6011ZM19.7924 17L15.0754 19.7321V14.2679L19.7924 17Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#161414"/>
                            <path d="M12.9895 19.0146C13.0725 18.3272 13.3544 17.9424 13.8857 17.5478C14.6459 17.0135 15.5954 17.3158 15.5954 17.3158V15.5227C15.8262 15.5168 16.0572 15.5305 16.2855 15.5636V17.8711C16.2855 17.8711 15.3362 17.5688 14.5761 18.1034C14.0451 18.4977 13.7626 18.8828 13.6799 19.5702C13.6773 19.9435 13.7473 20.4314 14.0699 20.8533C13.9902 20.8124 13.9089 20.7658 13.826 20.7135C13.1155 20.2363 12.986 19.5205 12.9895 19.0146ZM20.2061 12.2074C19.6832 11.6344 19.4855 11.0558 19.414 10.6494H20.0718C20.0718 10.6494 19.9406 11.715 20.8965 12.763L20.9098 12.777C20.6521 12.615 20.4159 12.4237 20.2061 12.2074ZM23.375 13.8319V16.093C23.375 16.093 22.5355 16.0601 21.9143 15.902C21.047 15.681 20.4895 15.342 20.4895 15.342C20.4895 15.342 20.1044 15.1003 20.0732 15.0834V19.7526C20.0732 20.0125 20.002 20.6618 19.785 21.2033C19.5016 21.9117 19.0643 22.3767 18.9839 22.4717C18.9839 22.4717 18.452 23.1002 17.5138 23.5235C16.668 23.9053 15.9254 23.8956 15.7035 23.9053C15.7035 23.9053 14.4199 23.9562 13.2648 23.2055C13.015 23.04 12.7819 22.8527 12.5684 22.6458L12.5741 22.6499C13.7295 23.4005 15.0128 23.3497 15.0128 23.3497C15.2351 23.34 15.9776 23.3497 16.8231 22.9679C17.7605 22.5446 18.2932 21.9161 18.2932 21.9161C18.3728 21.8211 18.8121 21.3561 19.0943 20.6474C19.3108 20.1062 19.3826 19.4567 19.3826 19.1967V14.5281C19.4137 14.5452 19.7985 14.787 19.7985 14.787C19.7985 14.787 20.3563 15.1263 21.2237 15.347C21.8452 15.505 22.6843 15.5379 22.6843 15.5379V13.7661C22.9714 13.8305 23.2161 13.8479 23.375 13.8319Z" fill="#EE1D52"/>
                            <path d="M22.6846 13.7661V15.5374C22.6846 15.5374 21.8455 15.5045 21.224 15.3464C20.3566 15.1254 19.7988 14.7864 19.7988 14.7864C19.7988 14.7864 19.414 14.5447 19.3828 14.5276V19.1972C19.3828 19.4572 19.3116 20.1067 19.0946 20.648C18.8112 21.3566 18.3739 21.8216 18.2935 21.9167C18.2935 21.9167 17.7614 22.5452 16.8234 22.9684C15.9779 23.3503 15.2354 23.3406 15.0131 23.3503C15.0131 23.3503 13.7298 23.4011 12.5744 22.6504L12.5687 22.6463C12.4467 22.5282 12.3319 22.4035 12.2248 22.2728C11.8561 21.8233 11.6301 21.2917 11.5733 21.14C11.5732 21.1394 11.5732 21.1387 11.5733 21.1381C11.4819 20.8745 11.2899 20.2416 11.3162 19.6285C11.3626 18.5469 11.7431 17.883 11.8437 17.7166C12.1101 17.2631 12.4567 16.8573 12.8679 16.5173C13.2307 16.2239 13.642 15.9905 14.0849 15.8266C14.5637 15.6342 15.0763 15.531 15.5954 15.5227V17.3158C15.5954 17.3158 14.6459 17.0146 13.886 17.5478C13.3547 17.9424 13.0728 18.3272 12.9898 19.0146C12.9863 19.5205 13.1158 20.2363 13.8258 20.7137C13.9086 20.7662 13.9899 20.8128 14.0696 20.8535C14.1937 21.0148 14.3446 21.1552 14.5164 21.2693C15.21 21.7083 15.7911 21.739 16.5343 21.4539C17.0298 21.2632 17.4028 20.8336 17.5757 20.3576C17.6844 20.0603 17.683 19.7611 17.683 19.4517V10.6494H19.4125C19.484 11.0558 19.6818 11.6344 20.2047 12.2074C20.4144 12.4237 20.6507 12.615 20.9083 12.777C20.9844 12.8558 21.3736 13.2451 21.8731 13.484C22.1314 13.6076 22.4037 13.7022 22.6846 13.7661Z" fill="white"/>
                            <path d="M10.8849 20.5894V20.5907L10.9278 20.7071C10.9229 20.6935 10.907 20.6523 10.8849 20.5894Z" fill="#69C9D0"/>
                            <path d="M14.0849 15.8266C13.6421 15.9905 13.2308 16.2239 12.8679 16.5173C12.4566 16.858 12.1101 17.2647 11.844 17.7191C11.7434 17.8849 11.3629 18.5493 11.3165 19.631C11.2902 20.244 11.4822 20.877 11.5736 21.1406C11.5735 21.1412 11.5735 21.1419 11.5736 21.1425C11.6313 21.2928 11.8564 21.8244 12.2251 22.2752C12.3322 22.4059 12.447 22.5307 12.569 22.6488C12.1781 22.3897 11.8296 22.0765 11.5347 21.7194C11.1692 21.2737 10.9438 20.7477 10.885 20.5924C10.8849 20.5913 10.8849 20.5902 10.885 20.5891V20.5872C10.7933 20.3239 10.6007 19.6906 10.6275 19.0768C10.6739 17.9951 11.0544 17.3312 11.1551 17.1649C11.4211 16.7104 11.7675 16.3038 12.179 15.9631C12.5418 15.6696 12.9531 15.4362 13.396 15.2724C13.6723 15.1625 13.9601 15.0815 14.2544 15.0306C14.6981 14.9564 15.1511 14.95 15.5969 15.0116V15.5227C15.0773 15.5308 14.5641 15.634 14.0849 15.8266Z" fill="#69C9D0"/>
                            <path d="M19.414 10.6496H17.6844V19.4522C17.6844 19.7616 17.6844 20.06 17.5772 20.3581C17.4025 20.8338 17.0309 21.2635 16.5357 21.4541C15.7923 21.7403 15.2111 21.7085 14.5179 21.2695C14.3458 21.156 14.1944 21.0159 14.0699 20.8551C14.6606 21.1571 15.1892 21.1518 15.8442 20.8999C16.3391 20.7092 16.7112 20.2796 16.8854 19.8036C16.9943 19.5063 16.9929 19.2071 16.9929 18.898V10.0938H19.3811C19.3811 10.0938 19.3543 10.3126 19.414 10.6496ZM22.6846 13.2765V13.7663C22.4042 13.7023 22.1324 13.6077 21.8746 13.4843C21.375 13.2453 20.9859 12.856 20.9098 12.7773C20.9981 12.8328 21.0897 12.8834 21.1842 12.9287C21.7916 13.2193 22.3897 13.3061 22.6846 13.2765Z" fill="#69C9D0"/>
                            </svg>
                            </a>
                        </picture>
                    </div>
                </div>
                <h4>Hanna Lê</h4>
            </div>
            <div class="public-figure-child">
                <picture>
                    <img src="./dist/img/Rectangle 12.png" alt="">
                </picture>
                <div class="public-figure-child-info">
                    <div>
                    <h5 class="btn-show-info">Đào Trang</h5>
                    <p>V-Top Channel</p>
                    </div>
                    <ul>
                        <li>12M lượt thích trên tiktok</li>
                        <li>10M followers</li>
                        <li>1000 virual videos</li>
                    </ul>
                    <div class="socail-info">
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#3B5998"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M20.7648 12.0119C20.3233 11.9236 19.7269 11.8577 19.3519 11.8577C18.3364 11.8577 18.2704 12.2992 18.2704 13.0056V14.2632H20.8089L20.5877 16.8682H18.2704V24.7918H15.092V16.8682H13.4583V14.2632H15.092V12.6519C15.092 10.4448 16.1293 9.2085 18.7338 9.2085C19.6386 9.2085 20.3009 9.34096 21.1616 9.51757L20.7648 12.0119Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#1DA1F2"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M25.5 11.5518C24.875 11.8294 24.2024 12.0164 23.497 12.1009C24.2172 11.6691 24.7702 10.9857 25.0303 10.1715C24.3571 10.5715 23.6097 10.8611 22.8159 11.018C22.1796 10.3403 21.2724 9.9165 20.27 9.9165C18.344 9.9165 16.7824 11.4781 16.7824 13.4041C16.7824 13.6772 16.8136 13.9435 16.8731 14.1991C13.9742 14.054 11.4045 12.6652 9.68425 10.5551C9.38394 11.0702 9.21225 11.6691 9.21225 12.3082C9.21225 13.518 9.82704 14.5855 10.7637 15.2111C10.1914 15.193 9.65422 15.036 9.18335 14.7748V14.8184C9.18335 16.5087 10.3863 17.9179 11.9808 18.2392C11.6884 18.3185 11.3802 18.3615 11.0623 18.3615C10.8373 18.3615 10.6186 18.3394 10.4056 18.2986C10.8492 19.6841 12.1378 20.6927 13.6637 20.721C12.4704 21.6559 10.9665 22.2141 9.33238 22.2141C9.0502 22.2141 8.77255 22.1976 8.5 22.1648C10.0435 23.1541 11.8765 23.7321 13.8461 23.7321C20.2609 23.7321 23.7689 18.4176 23.7689 13.8092C23.7689 13.658 23.7661 13.5072 23.7588 13.3582C24.441 12.8652 25.0325 12.251 25.5 11.5518Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#C13584"/>
                            <path d="M17 10.0315C19.2696 10.0315 19.5384 10.0402 20.4347 10.0811C21.2635 10.1189 21.7135 10.2573 22.0131 10.3738C22.4098 10.528 22.693 10.7121 22.9904 11.0096C23.2878 11.307 23.472 11.5902 23.6262 11.9869C23.7426 12.2864 23.8811 12.7365 23.9189 13.5653C23.9598 14.4615 23.9685 14.7304 23.9685 17C23.9685 19.2696 23.9598 19.5384 23.9189 20.4347C23.8811 21.2634 23.7426 21.7135 23.6262 22.013C23.472 22.4098 23.2878 22.6929 22.9904 22.9903C22.693 23.2878 22.4098 23.472 22.0131 23.6262C21.7135 23.7426 21.2635 23.8811 20.4347 23.9189C19.5386 23.9597 19.2698 23.9684 17 23.9684C14.7302 23.9684 14.4615 23.9597 13.5653 23.9189C12.7365 23.8811 12.2865 23.7426 11.9869 23.6262C11.5902 23.472 11.307 23.2878 11.0096 22.9903C10.7122 22.6929 10.528 22.4098 10.3738 22.013C10.2574 21.7135 10.1189 21.2634 10.0811 20.4347C10.0402 19.5384 10.0315 19.2696 10.0315 17C10.0315 14.7304 10.0402 14.4615 10.0811 13.5653C10.1189 12.7365 10.2574 12.2864 10.3738 11.9869C10.528 11.5902 10.7121 11.307 11.0096 11.0096C11.307 10.7121 11.5902 10.528 11.9869 10.3738C12.2865 10.2573 12.7365 10.1189 13.5653 10.0811C14.4616 10.0402 14.7304 10.0315 17 10.0315ZM17 8.5C14.6915 8.5 14.4021 8.50978 13.4955 8.55115C12.5907 8.59242 11.9728 8.73612 11.4322 8.94622C10.8732 9.16344 10.3992 9.45409 9.92663 9.92662C9.45409 10.3992 9.16345 10.8732 8.94626 11.4322C8.73612 11.9728 8.59242 12.5907 8.55115 13.4954C8.50978 14.4021 8.5 14.6915 8.5 17C8.5 19.3084 8.50978 19.5979 8.55115 20.5045C8.59242 21.4092 8.73612 22.0271 8.94626 22.5678C9.16345 23.1267 9.45409 23.6007 9.92663 24.0733C10.3992 24.5459 10.8732 24.8365 11.4322 25.0537C11.9728 25.2638 12.5907 25.4075 13.4955 25.4488C14.4021 25.4902 14.6915 25.4999 17 25.4999C19.3085 25.4999 19.5979 25.4902 20.5045 25.4488C21.4093 25.4075 22.0272 25.2638 22.5678 25.0537C23.1268 24.8365 23.6008 24.5459 24.0734 24.0733C24.5459 23.6007 24.8366 23.1267 25.0538 22.5678C25.2639 22.0271 25.4076 21.4092 25.4488 20.5045C25.4902 19.5979 25.5 19.3084 25.5 17C25.5 14.6915 25.4902 14.4021 25.4488 13.4954C25.4076 12.5907 25.2639 11.9728 25.0538 11.4322C24.8366 10.8732 24.5459 10.3992 24.0734 9.92662C23.6008 9.45409 23.1268 9.16344 22.5678 8.94622C22.0272 8.73612 21.4093 8.59242 20.5045 8.55115C19.5979 8.50978 19.3085 8.5 17 8.5Z" fill="white"/>
                            <path d="M17.0039 12.6392C14.5933 12.6392 12.6391 14.5934 12.6391 17.004C12.6391 19.4147 14.5933 21.3689 17.0039 21.3689C19.4146 21.3689 21.3688 19.4147 21.3688 17.004C21.3688 14.5934 19.4146 12.6392 17.0039 12.6392ZM17.0039 19.8373C15.4391 19.8373 14.1706 18.5688 14.1706 17.004C14.1706 15.4392 15.4391 14.1707 17.0039 14.1707C18.5687 14.1707 19.8373 15.4392 19.8373 17.004C19.8373 18.5688 18.5687 19.8373 17.0039 19.8373Z" fill="white"/>
                            <path d="M22.561 12.4639C22.561 13.0272 22.1043 13.4838 21.541 13.4838C20.9777 13.4838 20.521 13.0272 20.521 12.4639C20.521 11.9005 20.9777 11.4438 21.541 11.4438C22.1043 11.4438 22.561 11.9005 22.561 12.4639Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#FF0000"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M25.0045 11.6011C25.2872 11.8838 25.4909 12.2356 25.5953 12.6216C26.1966 15.042 26.0577 18.8646 25.607 21.3784C25.5026 21.7643 25.2989 22.1162 25.0162 22.3989C24.7335 22.6816 24.3817 22.8853 23.9957 22.9897C22.583 23.375 16.8968 23.375 16.8968 23.375C16.8968 23.375 11.2107 23.375 9.79794 22.9897C9.41203 22.8853 9.0602 22.6816 8.77751 22.3989C8.49481 22.1162 8.29111 21.7643 8.18668 21.3784C7.58187 18.9685 7.74767 15.1435 8.175 12.6332C8.27943 12.2473 8.48314 11.8955 8.76583 11.6128C9.04853 11.3301 9.40035 11.1264 9.78627 11.022C11.199 10.6367 16.8852 10.625 16.8852 10.625C16.8852 10.625 22.5713 10.625 23.9841 11.0103C24.37 11.1147 24.7218 11.3184 25.0045 11.6011ZM19.7924 17L15.0754 19.7321V14.2679L19.7924 17Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#161414"/>
                            <path d="M12.9895 19.0146C13.0725 18.3272 13.3544 17.9424 13.8857 17.5478C14.6459 17.0135 15.5954 17.3158 15.5954 17.3158V15.5227C15.8262 15.5168 16.0572 15.5305 16.2855 15.5636V17.8711C16.2855 17.8711 15.3362 17.5688 14.5761 18.1034C14.0451 18.4977 13.7626 18.8828 13.6799 19.5702C13.6773 19.9435 13.7473 20.4314 14.0699 20.8533C13.9902 20.8124 13.9089 20.7658 13.826 20.7135C13.1155 20.2363 12.986 19.5205 12.9895 19.0146ZM20.2061 12.2074C19.6832 11.6344 19.4855 11.0558 19.414 10.6494H20.0718C20.0718 10.6494 19.9406 11.715 20.8965 12.763L20.9098 12.777C20.6521 12.615 20.4159 12.4237 20.2061 12.2074ZM23.375 13.8319V16.093C23.375 16.093 22.5355 16.0601 21.9143 15.902C21.047 15.681 20.4895 15.342 20.4895 15.342C20.4895 15.342 20.1044 15.1003 20.0732 15.0834V19.7526C20.0732 20.0125 20.002 20.6618 19.785 21.2033C19.5016 21.9117 19.0643 22.3767 18.9839 22.4717C18.9839 22.4717 18.452 23.1002 17.5138 23.5235C16.668 23.9053 15.9254 23.8956 15.7035 23.9053C15.7035 23.9053 14.4199 23.9562 13.2648 23.2055C13.015 23.04 12.7819 22.8527 12.5684 22.6458L12.5741 22.6499C13.7295 23.4005 15.0128 23.3497 15.0128 23.3497C15.2351 23.34 15.9776 23.3497 16.8231 22.9679C17.7605 22.5446 18.2932 21.9161 18.2932 21.9161C18.3728 21.8211 18.8121 21.3561 19.0943 20.6474C19.3108 20.1062 19.3826 19.4567 19.3826 19.1967V14.5281C19.4137 14.5452 19.7985 14.787 19.7985 14.787C19.7985 14.787 20.3563 15.1263 21.2237 15.347C21.8452 15.505 22.6843 15.5379 22.6843 15.5379V13.7661C22.9714 13.8305 23.2161 13.8479 23.375 13.8319Z" fill="#EE1D52"/>
                            <path d="M22.6846 13.7661V15.5374C22.6846 15.5374 21.8455 15.5045 21.224 15.3464C20.3566 15.1254 19.7988 14.7864 19.7988 14.7864C19.7988 14.7864 19.414 14.5447 19.3828 14.5276V19.1972C19.3828 19.4572 19.3116 20.1067 19.0946 20.648C18.8112 21.3566 18.3739 21.8216 18.2935 21.9167C18.2935 21.9167 17.7614 22.5452 16.8234 22.9684C15.9779 23.3503 15.2354 23.3406 15.0131 23.3503C15.0131 23.3503 13.7298 23.4011 12.5744 22.6504L12.5687 22.6463C12.4467 22.5282 12.3319 22.4035 12.2248 22.2728C11.8561 21.8233 11.6301 21.2917 11.5733 21.14C11.5732 21.1394 11.5732 21.1387 11.5733 21.1381C11.4819 20.8745 11.2899 20.2416 11.3162 19.6285C11.3626 18.5469 11.7431 17.883 11.8437 17.7166C12.1101 17.2631 12.4567 16.8573 12.8679 16.5173C13.2307 16.2239 13.642 15.9905 14.0849 15.8266C14.5637 15.6342 15.0763 15.531 15.5954 15.5227V17.3158C15.5954 17.3158 14.6459 17.0146 13.886 17.5478C13.3547 17.9424 13.0728 18.3272 12.9898 19.0146C12.9863 19.5205 13.1158 20.2363 13.8258 20.7137C13.9086 20.7662 13.9899 20.8128 14.0696 20.8535C14.1937 21.0148 14.3446 21.1552 14.5164 21.2693C15.21 21.7083 15.7911 21.739 16.5343 21.4539C17.0298 21.2632 17.4028 20.8336 17.5757 20.3576C17.6844 20.0603 17.683 19.7611 17.683 19.4517V10.6494H19.4125C19.484 11.0558 19.6818 11.6344 20.2047 12.2074C20.4144 12.4237 20.6507 12.615 20.9083 12.777C20.9844 12.8558 21.3736 13.2451 21.8731 13.484C22.1314 13.6076 22.4037 13.7022 22.6846 13.7661Z" fill="white"/>
                            <path d="M10.8849 20.5894V20.5907L10.9278 20.7071C10.9229 20.6935 10.907 20.6523 10.8849 20.5894Z" fill="#69C9D0"/>
                            <path d="M14.0849 15.8266C13.6421 15.9905 13.2308 16.2239 12.8679 16.5173C12.4566 16.858 12.1101 17.2647 11.844 17.7191C11.7434 17.8849 11.3629 18.5493 11.3165 19.631C11.2902 20.244 11.4822 20.877 11.5736 21.1406C11.5735 21.1412 11.5735 21.1419 11.5736 21.1425C11.6313 21.2928 11.8564 21.8244 12.2251 22.2752C12.3322 22.4059 12.447 22.5307 12.569 22.6488C12.1781 22.3897 11.8296 22.0765 11.5347 21.7194C11.1692 21.2737 10.9438 20.7477 10.885 20.5924C10.8849 20.5913 10.8849 20.5902 10.885 20.5891V20.5872C10.7933 20.3239 10.6007 19.6906 10.6275 19.0768C10.6739 17.9951 11.0544 17.3312 11.1551 17.1649C11.4211 16.7104 11.7675 16.3038 12.179 15.9631C12.5418 15.6696 12.9531 15.4362 13.396 15.2724C13.6723 15.1625 13.9601 15.0815 14.2544 15.0306C14.6981 14.9564 15.1511 14.95 15.5969 15.0116V15.5227C15.0773 15.5308 14.5641 15.634 14.0849 15.8266Z" fill="#69C9D0"/>
                            <path d="M19.414 10.6496H17.6844V19.4522C17.6844 19.7616 17.6844 20.06 17.5772 20.3581C17.4025 20.8338 17.0309 21.2635 16.5357 21.4541C15.7923 21.7403 15.2111 21.7085 14.5179 21.2695C14.3458 21.156 14.1944 21.0159 14.0699 20.8551C14.6606 21.1571 15.1892 21.1518 15.8442 20.8999C16.3391 20.7092 16.7112 20.2796 16.8854 19.8036C16.9943 19.5063 16.9929 19.2071 16.9929 18.898V10.0938H19.3811C19.3811 10.0938 19.3543 10.3126 19.414 10.6496ZM22.6846 13.2765V13.7663C22.4042 13.7023 22.1324 13.6077 21.8746 13.4843C21.375 13.2453 20.9859 12.856 20.9098 12.7773C20.9981 12.8328 21.0897 12.8834 21.1842 12.9287C21.7916 13.2193 22.3897 13.3061 22.6846 13.2765Z" fill="#69C9D0"/>
                            </svg>
                            </a>
                        </picture>
                    </div>
                </div>
                <h4>Đào Trang</h4>
            </div>
            <div class="public-figure-child">
                <picture>
                    <img src="./dist/img/Rectangle 13.png" alt="">
                </picture>
                <div class="public-figure-child-info">
                    <div>
                    <h5 class="btn-show-info">Cindy</h5>
                    <p>V-Top Channel</p>
                    </div>
                    <ul>
                        <li>12M lượt thích trên tiktok</li>
                        <li>10M followers</li>
                        <li>1000 virual videos</li>
                    </ul>
                    <div class="socail-info">
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#3B5998"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M20.7648 12.0119C20.3233 11.9236 19.7269 11.8577 19.3519 11.8577C18.3364 11.8577 18.2704 12.2992 18.2704 13.0056V14.2632H20.8089L20.5877 16.8682H18.2704V24.7918H15.092V16.8682H13.4583V14.2632H15.092V12.6519C15.092 10.4448 16.1293 9.2085 18.7338 9.2085C19.6386 9.2085 20.3009 9.34096 21.1616 9.51757L20.7648 12.0119Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#1DA1F2"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M25.5 11.5518C24.875 11.8294 24.2024 12.0164 23.497 12.1009C24.2172 11.6691 24.7702 10.9857 25.0303 10.1715C24.3571 10.5715 23.6097 10.8611 22.8159 11.018C22.1796 10.3403 21.2724 9.9165 20.27 9.9165C18.344 9.9165 16.7824 11.4781 16.7824 13.4041C16.7824 13.6772 16.8136 13.9435 16.8731 14.1991C13.9742 14.054 11.4045 12.6652 9.68425 10.5551C9.38394 11.0702 9.21225 11.6691 9.21225 12.3082C9.21225 13.518 9.82704 14.5855 10.7637 15.2111C10.1914 15.193 9.65422 15.036 9.18335 14.7748V14.8184C9.18335 16.5087 10.3863 17.9179 11.9808 18.2392C11.6884 18.3185 11.3802 18.3615 11.0623 18.3615C10.8373 18.3615 10.6186 18.3394 10.4056 18.2986C10.8492 19.6841 12.1378 20.6927 13.6637 20.721C12.4704 21.6559 10.9665 22.2141 9.33238 22.2141C9.0502 22.2141 8.77255 22.1976 8.5 22.1648C10.0435 23.1541 11.8765 23.7321 13.8461 23.7321C20.2609 23.7321 23.7689 18.4176 23.7689 13.8092C23.7689 13.658 23.7661 13.5072 23.7588 13.3582C24.441 12.8652 25.0325 12.251 25.5 11.5518Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#C13584"/>
                            <path d="M17 10.0315C19.2696 10.0315 19.5384 10.0402 20.4347 10.0811C21.2635 10.1189 21.7135 10.2573 22.0131 10.3738C22.4098 10.528 22.693 10.7121 22.9904 11.0096C23.2878 11.307 23.472 11.5902 23.6262 11.9869C23.7426 12.2864 23.8811 12.7365 23.9189 13.5653C23.9598 14.4615 23.9685 14.7304 23.9685 17C23.9685 19.2696 23.9598 19.5384 23.9189 20.4347C23.8811 21.2634 23.7426 21.7135 23.6262 22.013C23.472 22.4098 23.2878 22.6929 22.9904 22.9903C22.693 23.2878 22.4098 23.472 22.0131 23.6262C21.7135 23.7426 21.2635 23.8811 20.4347 23.9189C19.5386 23.9597 19.2698 23.9684 17 23.9684C14.7302 23.9684 14.4615 23.9597 13.5653 23.9189C12.7365 23.8811 12.2865 23.7426 11.9869 23.6262C11.5902 23.472 11.307 23.2878 11.0096 22.9903C10.7122 22.6929 10.528 22.4098 10.3738 22.013C10.2574 21.7135 10.1189 21.2634 10.0811 20.4347C10.0402 19.5384 10.0315 19.2696 10.0315 17C10.0315 14.7304 10.0402 14.4615 10.0811 13.5653C10.1189 12.7365 10.2574 12.2864 10.3738 11.9869C10.528 11.5902 10.7121 11.307 11.0096 11.0096C11.307 10.7121 11.5902 10.528 11.9869 10.3738C12.2865 10.2573 12.7365 10.1189 13.5653 10.0811C14.4616 10.0402 14.7304 10.0315 17 10.0315ZM17 8.5C14.6915 8.5 14.4021 8.50978 13.4955 8.55115C12.5907 8.59242 11.9728 8.73612 11.4322 8.94622C10.8732 9.16344 10.3992 9.45409 9.92663 9.92662C9.45409 10.3992 9.16345 10.8732 8.94626 11.4322C8.73612 11.9728 8.59242 12.5907 8.55115 13.4954C8.50978 14.4021 8.5 14.6915 8.5 17C8.5 19.3084 8.50978 19.5979 8.55115 20.5045C8.59242 21.4092 8.73612 22.0271 8.94626 22.5678C9.16345 23.1267 9.45409 23.6007 9.92663 24.0733C10.3992 24.5459 10.8732 24.8365 11.4322 25.0537C11.9728 25.2638 12.5907 25.4075 13.4955 25.4488C14.4021 25.4902 14.6915 25.4999 17 25.4999C19.3085 25.4999 19.5979 25.4902 20.5045 25.4488C21.4093 25.4075 22.0272 25.2638 22.5678 25.0537C23.1268 24.8365 23.6008 24.5459 24.0734 24.0733C24.5459 23.6007 24.8366 23.1267 25.0538 22.5678C25.2639 22.0271 25.4076 21.4092 25.4488 20.5045C25.4902 19.5979 25.5 19.3084 25.5 17C25.5 14.6915 25.4902 14.4021 25.4488 13.4954C25.4076 12.5907 25.2639 11.9728 25.0538 11.4322C24.8366 10.8732 24.5459 10.3992 24.0734 9.92662C23.6008 9.45409 23.1268 9.16344 22.5678 8.94622C22.0272 8.73612 21.4093 8.59242 20.5045 8.55115C19.5979 8.50978 19.3085 8.5 17 8.5Z" fill="white"/>
                            <path d="M17.0039 12.6392C14.5933 12.6392 12.6391 14.5934 12.6391 17.004C12.6391 19.4147 14.5933 21.3689 17.0039 21.3689C19.4146 21.3689 21.3688 19.4147 21.3688 17.004C21.3688 14.5934 19.4146 12.6392 17.0039 12.6392ZM17.0039 19.8373C15.4391 19.8373 14.1706 18.5688 14.1706 17.004C14.1706 15.4392 15.4391 14.1707 17.0039 14.1707C18.5687 14.1707 19.8373 15.4392 19.8373 17.004C19.8373 18.5688 18.5687 19.8373 17.0039 19.8373Z" fill="white"/>
                            <path d="M22.561 12.4639C22.561 13.0272 22.1043 13.4838 21.541 13.4838C20.9777 13.4838 20.521 13.0272 20.521 12.4639C20.521 11.9005 20.9777 11.4438 21.541 11.4438C22.1043 11.4438 22.561 11.9005 22.561 12.4639Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#FF0000"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M25.0045 11.6011C25.2872 11.8838 25.4909 12.2356 25.5953 12.6216C26.1966 15.042 26.0577 18.8646 25.607 21.3784C25.5026 21.7643 25.2989 22.1162 25.0162 22.3989C24.7335 22.6816 24.3817 22.8853 23.9957 22.9897C22.583 23.375 16.8968 23.375 16.8968 23.375C16.8968 23.375 11.2107 23.375 9.79794 22.9897C9.41203 22.8853 9.0602 22.6816 8.77751 22.3989C8.49481 22.1162 8.29111 21.7643 8.18668 21.3784C7.58187 18.9685 7.74767 15.1435 8.175 12.6332C8.27943 12.2473 8.48314 11.8955 8.76583 11.6128C9.04853 11.3301 9.40035 11.1264 9.78627 11.022C11.199 10.6367 16.8852 10.625 16.8852 10.625C16.8852 10.625 22.5713 10.625 23.9841 11.0103C24.37 11.1147 24.7218 11.3184 25.0045 11.6011ZM19.7924 17L15.0754 19.7321V14.2679L19.7924 17Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#161414"/>
                            <path d="M12.9895 19.0146C13.0725 18.3272 13.3544 17.9424 13.8857 17.5478C14.6459 17.0135 15.5954 17.3158 15.5954 17.3158V15.5227C15.8262 15.5168 16.0572 15.5305 16.2855 15.5636V17.8711C16.2855 17.8711 15.3362 17.5688 14.5761 18.1034C14.0451 18.4977 13.7626 18.8828 13.6799 19.5702C13.6773 19.9435 13.7473 20.4314 14.0699 20.8533C13.9902 20.8124 13.9089 20.7658 13.826 20.7135C13.1155 20.2363 12.986 19.5205 12.9895 19.0146ZM20.2061 12.2074C19.6832 11.6344 19.4855 11.0558 19.414 10.6494H20.0718C20.0718 10.6494 19.9406 11.715 20.8965 12.763L20.9098 12.777C20.6521 12.615 20.4159 12.4237 20.2061 12.2074ZM23.375 13.8319V16.093C23.375 16.093 22.5355 16.0601 21.9143 15.902C21.047 15.681 20.4895 15.342 20.4895 15.342C20.4895 15.342 20.1044 15.1003 20.0732 15.0834V19.7526C20.0732 20.0125 20.002 20.6618 19.785 21.2033C19.5016 21.9117 19.0643 22.3767 18.9839 22.4717C18.9839 22.4717 18.452 23.1002 17.5138 23.5235C16.668 23.9053 15.9254 23.8956 15.7035 23.9053C15.7035 23.9053 14.4199 23.9562 13.2648 23.2055C13.015 23.04 12.7819 22.8527 12.5684 22.6458L12.5741 22.6499C13.7295 23.4005 15.0128 23.3497 15.0128 23.3497C15.2351 23.34 15.9776 23.3497 16.8231 22.9679C17.7605 22.5446 18.2932 21.9161 18.2932 21.9161C18.3728 21.8211 18.8121 21.3561 19.0943 20.6474C19.3108 20.1062 19.3826 19.4567 19.3826 19.1967V14.5281C19.4137 14.5452 19.7985 14.787 19.7985 14.787C19.7985 14.787 20.3563 15.1263 21.2237 15.347C21.8452 15.505 22.6843 15.5379 22.6843 15.5379V13.7661C22.9714 13.8305 23.2161 13.8479 23.375 13.8319Z" fill="#EE1D52"/>
                            <path d="M22.6846 13.7661V15.5374C22.6846 15.5374 21.8455 15.5045 21.224 15.3464C20.3566 15.1254 19.7988 14.7864 19.7988 14.7864C19.7988 14.7864 19.414 14.5447 19.3828 14.5276V19.1972C19.3828 19.4572 19.3116 20.1067 19.0946 20.648C18.8112 21.3566 18.3739 21.8216 18.2935 21.9167C18.2935 21.9167 17.7614 22.5452 16.8234 22.9684C15.9779 23.3503 15.2354 23.3406 15.0131 23.3503C15.0131 23.3503 13.7298 23.4011 12.5744 22.6504L12.5687 22.6463C12.4467 22.5282 12.3319 22.4035 12.2248 22.2728C11.8561 21.8233 11.6301 21.2917 11.5733 21.14C11.5732 21.1394 11.5732 21.1387 11.5733 21.1381C11.4819 20.8745 11.2899 20.2416 11.3162 19.6285C11.3626 18.5469 11.7431 17.883 11.8437 17.7166C12.1101 17.2631 12.4567 16.8573 12.8679 16.5173C13.2307 16.2239 13.642 15.9905 14.0849 15.8266C14.5637 15.6342 15.0763 15.531 15.5954 15.5227V17.3158C15.5954 17.3158 14.6459 17.0146 13.886 17.5478C13.3547 17.9424 13.0728 18.3272 12.9898 19.0146C12.9863 19.5205 13.1158 20.2363 13.8258 20.7137C13.9086 20.7662 13.9899 20.8128 14.0696 20.8535C14.1937 21.0148 14.3446 21.1552 14.5164 21.2693C15.21 21.7083 15.7911 21.739 16.5343 21.4539C17.0298 21.2632 17.4028 20.8336 17.5757 20.3576C17.6844 20.0603 17.683 19.7611 17.683 19.4517V10.6494H19.4125C19.484 11.0558 19.6818 11.6344 20.2047 12.2074C20.4144 12.4237 20.6507 12.615 20.9083 12.777C20.9844 12.8558 21.3736 13.2451 21.8731 13.484C22.1314 13.6076 22.4037 13.7022 22.6846 13.7661Z" fill="white"/>
                            <path d="M10.8849 20.5894V20.5907L10.9278 20.7071C10.9229 20.6935 10.907 20.6523 10.8849 20.5894Z" fill="#69C9D0"/>
                            <path d="M14.0849 15.8266C13.6421 15.9905 13.2308 16.2239 12.8679 16.5173C12.4566 16.858 12.1101 17.2647 11.844 17.7191C11.7434 17.8849 11.3629 18.5493 11.3165 19.631C11.2902 20.244 11.4822 20.877 11.5736 21.1406C11.5735 21.1412 11.5735 21.1419 11.5736 21.1425C11.6313 21.2928 11.8564 21.8244 12.2251 22.2752C12.3322 22.4059 12.447 22.5307 12.569 22.6488C12.1781 22.3897 11.8296 22.0765 11.5347 21.7194C11.1692 21.2737 10.9438 20.7477 10.885 20.5924C10.8849 20.5913 10.8849 20.5902 10.885 20.5891V20.5872C10.7933 20.3239 10.6007 19.6906 10.6275 19.0768C10.6739 17.9951 11.0544 17.3312 11.1551 17.1649C11.4211 16.7104 11.7675 16.3038 12.179 15.9631C12.5418 15.6696 12.9531 15.4362 13.396 15.2724C13.6723 15.1625 13.9601 15.0815 14.2544 15.0306C14.6981 14.9564 15.1511 14.95 15.5969 15.0116V15.5227C15.0773 15.5308 14.5641 15.634 14.0849 15.8266Z" fill="#69C9D0"/>
                            <path d="M19.414 10.6496H17.6844V19.4522C17.6844 19.7616 17.6844 20.06 17.5772 20.3581C17.4025 20.8338 17.0309 21.2635 16.5357 21.4541C15.7923 21.7403 15.2111 21.7085 14.5179 21.2695C14.3458 21.156 14.1944 21.0159 14.0699 20.8551C14.6606 21.1571 15.1892 21.1518 15.8442 20.8999C16.3391 20.7092 16.7112 20.2796 16.8854 19.8036C16.9943 19.5063 16.9929 19.2071 16.9929 18.898V10.0938H19.3811C19.3811 10.0938 19.3543 10.3126 19.414 10.6496ZM22.6846 13.2765V13.7663C22.4042 13.7023 22.1324 13.6077 21.8746 13.4843C21.375 13.2453 20.9859 12.856 20.9098 12.7773C20.9981 12.8328 21.0897 12.8834 21.1842 12.9287C21.7916 13.2193 22.3897 13.3061 22.6846 13.2765Z" fill="#69C9D0"/>
                            </svg>
                            </a>
                        </picture>
                    </div>
                </div>
                <h4>Cindy</h4>
            </div>
            <div class="public-figure-child">
                <picture>
                    <img src="./dist/img/Rectangle 14.png" alt="">
                </picture>
                <div class="public-figure-child-info">
                    <div>
                    <h5 class="btn-show-info">Uyên Camitie</h5>
                    <p>V-Top Channel</p>
                    </div>
                    <ul>
                        <li>12M lượt thích trên tiktok</li>
                        <li>10M followers</li>
                        <li>1000 virual videos</li>
                    </ul>
                    <div class="socail-info">
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#3B5998"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M20.7648 12.0119C20.3233 11.9236 19.7269 11.8577 19.3519 11.8577C18.3364 11.8577 18.2704 12.2992 18.2704 13.0056V14.2632H20.8089L20.5877 16.8682H18.2704V24.7918H15.092V16.8682H13.4583V14.2632H15.092V12.6519C15.092 10.4448 16.1293 9.2085 18.7338 9.2085C19.6386 9.2085 20.3009 9.34096 21.1616 9.51757L20.7648 12.0119Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#1DA1F2"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M25.5 11.5518C24.875 11.8294 24.2024 12.0164 23.497 12.1009C24.2172 11.6691 24.7702 10.9857 25.0303 10.1715C24.3571 10.5715 23.6097 10.8611 22.8159 11.018C22.1796 10.3403 21.2724 9.9165 20.27 9.9165C18.344 9.9165 16.7824 11.4781 16.7824 13.4041C16.7824 13.6772 16.8136 13.9435 16.8731 14.1991C13.9742 14.054 11.4045 12.6652 9.68425 10.5551C9.38394 11.0702 9.21225 11.6691 9.21225 12.3082C9.21225 13.518 9.82704 14.5855 10.7637 15.2111C10.1914 15.193 9.65422 15.036 9.18335 14.7748V14.8184C9.18335 16.5087 10.3863 17.9179 11.9808 18.2392C11.6884 18.3185 11.3802 18.3615 11.0623 18.3615C10.8373 18.3615 10.6186 18.3394 10.4056 18.2986C10.8492 19.6841 12.1378 20.6927 13.6637 20.721C12.4704 21.6559 10.9665 22.2141 9.33238 22.2141C9.0502 22.2141 8.77255 22.1976 8.5 22.1648C10.0435 23.1541 11.8765 23.7321 13.8461 23.7321C20.2609 23.7321 23.7689 18.4176 23.7689 13.8092C23.7689 13.658 23.7661 13.5072 23.7588 13.3582C24.441 12.8652 25.0325 12.251 25.5 11.5518Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#C13584"/>
                            <path d="M17 10.0315C19.2696 10.0315 19.5384 10.0402 20.4347 10.0811C21.2635 10.1189 21.7135 10.2573 22.0131 10.3738C22.4098 10.528 22.693 10.7121 22.9904 11.0096C23.2878 11.307 23.472 11.5902 23.6262 11.9869C23.7426 12.2864 23.8811 12.7365 23.9189 13.5653C23.9598 14.4615 23.9685 14.7304 23.9685 17C23.9685 19.2696 23.9598 19.5384 23.9189 20.4347C23.8811 21.2634 23.7426 21.7135 23.6262 22.013C23.472 22.4098 23.2878 22.6929 22.9904 22.9903C22.693 23.2878 22.4098 23.472 22.0131 23.6262C21.7135 23.7426 21.2635 23.8811 20.4347 23.9189C19.5386 23.9597 19.2698 23.9684 17 23.9684C14.7302 23.9684 14.4615 23.9597 13.5653 23.9189C12.7365 23.8811 12.2865 23.7426 11.9869 23.6262C11.5902 23.472 11.307 23.2878 11.0096 22.9903C10.7122 22.6929 10.528 22.4098 10.3738 22.013C10.2574 21.7135 10.1189 21.2634 10.0811 20.4347C10.0402 19.5384 10.0315 19.2696 10.0315 17C10.0315 14.7304 10.0402 14.4615 10.0811 13.5653C10.1189 12.7365 10.2574 12.2864 10.3738 11.9869C10.528 11.5902 10.7121 11.307 11.0096 11.0096C11.307 10.7121 11.5902 10.528 11.9869 10.3738C12.2865 10.2573 12.7365 10.1189 13.5653 10.0811C14.4616 10.0402 14.7304 10.0315 17 10.0315ZM17 8.5C14.6915 8.5 14.4021 8.50978 13.4955 8.55115C12.5907 8.59242 11.9728 8.73612 11.4322 8.94622C10.8732 9.16344 10.3992 9.45409 9.92663 9.92662C9.45409 10.3992 9.16345 10.8732 8.94626 11.4322C8.73612 11.9728 8.59242 12.5907 8.55115 13.4954C8.50978 14.4021 8.5 14.6915 8.5 17C8.5 19.3084 8.50978 19.5979 8.55115 20.5045C8.59242 21.4092 8.73612 22.0271 8.94626 22.5678C9.16345 23.1267 9.45409 23.6007 9.92663 24.0733C10.3992 24.5459 10.8732 24.8365 11.4322 25.0537C11.9728 25.2638 12.5907 25.4075 13.4955 25.4488C14.4021 25.4902 14.6915 25.4999 17 25.4999C19.3085 25.4999 19.5979 25.4902 20.5045 25.4488C21.4093 25.4075 22.0272 25.2638 22.5678 25.0537C23.1268 24.8365 23.6008 24.5459 24.0734 24.0733C24.5459 23.6007 24.8366 23.1267 25.0538 22.5678C25.2639 22.0271 25.4076 21.4092 25.4488 20.5045C25.4902 19.5979 25.5 19.3084 25.5 17C25.5 14.6915 25.4902 14.4021 25.4488 13.4954C25.4076 12.5907 25.2639 11.9728 25.0538 11.4322C24.8366 10.8732 24.5459 10.3992 24.0734 9.92662C23.6008 9.45409 23.1268 9.16344 22.5678 8.94622C22.0272 8.73612 21.4093 8.59242 20.5045 8.55115C19.5979 8.50978 19.3085 8.5 17 8.5Z" fill="white"/>
                            <path d="M17.0039 12.6392C14.5933 12.6392 12.6391 14.5934 12.6391 17.004C12.6391 19.4147 14.5933 21.3689 17.0039 21.3689C19.4146 21.3689 21.3688 19.4147 21.3688 17.004C21.3688 14.5934 19.4146 12.6392 17.0039 12.6392ZM17.0039 19.8373C15.4391 19.8373 14.1706 18.5688 14.1706 17.004C14.1706 15.4392 15.4391 14.1707 17.0039 14.1707C18.5687 14.1707 19.8373 15.4392 19.8373 17.004C19.8373 18.5688 18.5687 19.8373 17.0039 19.8373Z" fill="white"/>
                            <path d="M22.561 12.4639C22.561 13.0272 22.1043 13.4838 21.541 13.4838C20.9777 13.4838 20.521 13.0272 20.521 12.4639C20.521 11.9005 20.9777 11.4438 21.541 11.4438C22.1043 11.4438 22.561 11.9005 22.561 12.4639Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#FF0000"/>
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M25.0045 11.6011C25.2872 11.8838 25.4909 12.2356 25.5953 12.6216C26.1966 15.042 26.0577 18.8646 25.607 21.3784C25.5026 21.7643 25.2989 22.1162 25.0162 22.3989C24.7335 22.6816 24.3817 22.8853 23.9957 22.9897C22.583 23.375 16.8968 23.375 16.8968 23.375C16.8968 23.375 11.2107 23.375 9.79794 22.9897C9.41203 22.8853 9.0602 22.6816 8.77751 22.3989C8.49481 22.1162 8.29111 21.7643 8.18668 21.3784C7.58187 18.9685 7.74767 15.1435 8.175 12.6332C8.27943 12.2473 8.48314 11.8955 8.76583 11.6128C9.04853 11.3301 9.40035 11.1264 9.78627 11.022C11.199 10.6367 16.8852 10.625 16.8852 10.625C16.8852 10.625 22.5713 10.625 23.9841 11.0103C24.37 11.1147 24.7218 11.3184 25.0045 11.6011ZM19.7924 17L15.0754 19.7321V14.2679L19.7924 17Z" fill="white"/>
                            </svg>
                            </a>
                        </picture>
                        <picture>
                            <a href="#">
                                <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <circle cx="17" cy="17.0002" r="14.1667" fill="#161414"/>
                            <path d="M12.9895 19.0146C13.0725 18.3272 13.3544 17.9424 13.8857 17.5478C14.6459 17.0135 15.5954 17.3158 15.5954 17.3158V15.5227C15.8262 15.5168 16.0572 15.5305 16.2855 15.5636V17.8711C16.2855 17.8711 15.3362 17.5688 14.5761 18.1034C14.0451 18.4977 13.7626 18.8828 13.6799 19.5702C13.6773 19.9435 13.7473 20.4314 14.0699 20.8533C13.9902 20.8124 13.9089 20.7658 13.826 20.7135C13.1155 20.2363 12.986 19.5205 12.9895 19.0146ZM20.2061 12.2074C19.6832 11.6344 19.4855 11.0558 19.414 10.6494H20.0718C20.0718 10.6494 19.9406 11.715 20.8965 12.763L20.9098 12.777C20.6521 12.615 20.4159 12.4237 20.2061 12.2074ZM23.375 13.8319V16.093C23.375 16.093 22.5355 16.0601 21.9143 15.902C21.047 15.681 20.4895 15.342 20.4895 15.342C20.4895 15.342 20.1044 15.1003 20.0732 15.0834V19.7526C20.0732 20.0125 20.002 20.6618 19.785 21.2033C19.5016 21.9117 19.0643 22.3767 18.9839 22.4717C18.9839 22.4717 18.452 23.1002 17.5138 23.5235C16.668 23.9053 15.9254 23.8956 15.7035 23.9053C15.7035 23.9053 14.4199 23.9562 13.2648 23.2055C13.015 23.04 12.7819 22.8527 12.5684 22.6458L12.5741 22.6499C13.7295 23.4005 15.0128 23.3497 15.0128 23.3497C15.2351 23.34 15.9776 23.3497 16.8231 22.9679C17.7605 22.5446 18.2932 21.9161 18.2932 21.9161C18.3728 21.8211 18.8121 21.3561 19.0943 20.6474C19.3108 20.1062 19.3826 19.4567 19.3826 19.1967V14.5281C19.4137 14.5452 19.7985 14.787 19.7985 14.787C19.7985 14.787 20.3563 15.1263 21.2237 15.347C21.8452 15.505 22.6843 15.5379 22.6843 15.5379V13.7661C22.9714 13.8305 23.2161 13.8479 23.375 13.8319Z" fill="#EE1D52"/>
                            <path d="M22.6846 13.7661V15.5374C22.6846 15.5374 21.8455 15.5045 21.224 15.3464C20.3566 15.1254 19.7988 14.7864 19.7988 14.7864C19.7988 14.7864 19.414 14.5447 19.3828 14.5276V19.1972C19.3828 19.4572 19.3116 20.1067 19.0946 20.648C18.8112 21.3566 18.3739 21.8216 18.2935 21.9167C18.2935 21.9167 17.7614 22.5452 16.8234 22.9684C15.9779 23.3503 15.2354 23.3406 15.0131 23.3503C15.0131 23.3503 13.7298 23.4011 12.5744 22.6504L12.5687 22.6463C12.4467 22.5282 12.3319 22.4035 12.2248 22.2728C11.8561 21.8233 11.6301 21.2917 11.5733 21.14C11.5732 21.1394 11.5732 21.1387 11.5733 21.1381C11.4819 20.8745 11.2899 20.2416 11.3162 19.6285C11.3626 18.5469 11.7431 17.883 11.8437 17.7166C12.1101 17.2631 12.4567 16.8573 12.8679 16.5173C13.2307 16.2239 13.642 15.9905 14.0849 15.8266C14.5637 15.6342 15.0763 15.531 15.5954 15.5227V17.3158C15.5954 17.3158 14.6459 17.0146 13.886 17.5478C13.3547 17.9424 13.0728 18.3272 12.9898 19.0146C12.9863 19.5205 13.1158 20.2363 13.8258 20.7137C13.9086 20.7662 13.9899 20.8128 14.0696 20.8535C14.1937 21.0148 14.3446 21.1552 14.5164 21.2693C15.21 21.7083 15.7911 21.739 16.5343 21.4539C17.0298 21.2632 17.4028 20.8336 17.5757 20.3576C17.6844 20.0603 17.683 19.7611 17.683 19.4517V10.6494H19.4125C19.484 11.0558 19.6818 11.6344 20.2047 12.2074C20.4144 12.4237 20.6507 12.615 20.9083 12.777C20.9844 12.8558 21.3736 13.2451 21.8731 13.484C22.1314 13.6076 22.4037 13.7022 22.6846 13.7661Z" fill="white"/>
                            <path d="M10.8849 20.5894V20.5907L10.9278 20.7071C10.9229 20.6935 10.907 20.6523 10.8849 20.5894Z" fill="#69C9D0"/>
                            <path d="M14.0849 15.8266C13.6421 15.9905 13.2308 16.2239 12.8679 16.5173C12.4566 16.858 12.1101 17.2647 11.844 17.7191C11.7434 17.8849 11.3629 18.5493 11.3165 19.631C11.2902 20.244 11.4822 20.877 11.5736 21.1406C11.5735 21.1412 11.5735 21.1419 11.5736 21.1425C11.6313 21.2928 11.8564 21.8244 12.2251 22.2752C12.3322 22.4059 12.447 22.5307 12.569 22.6488C12.1781 22.3897 11.8296 22.0765 11.5347 21.7194C11.1692 21.2737 10.9438 20.7477 10.885 20.5924C10.8849 20.5913 10.8849 20.5902 10.885 20.5891V20.5872C10.7933 20.3239 10.6007 19.6906 10.6275 19.0768C10.6739 17.9951 11.0544 17.3312 11.1551 17.1649C11.4211 16.7104 11.7675 16.3038 12.179 15.9631C12.5418 15.6696 12.9531 15.4362 13.396 15.2724C13.6723 15.1625 13.9601 15.0815 14.2544 15.0306C14.6981 14.9564 15.1511 14.95 15.5969 15.0116V15.5227C15.0773 15.5308 14.5641 15.634 14.0849 15.8266Z" fill="#69C9D0"/>
                            <path d="M19.414 10.6496H17.6844V19.4522C17.6844 19.7616 17.6844 20.06 17.5772 20.3581C17.4025 20.8338 17.0309 21.2635 16.5357 21.4541C15.7923 21.7403 15.2111 21.7085 14.5179 21.2695C14.3458 21.156 14.1944 21.0159 14.0699 20.8551C14.6606 21.1571 15.1892 21.1518 15.8442 20.8999C16.3391 20.7092 16.7112 20.2796 16.8854 19.8036C16.9943 19.5063 16.9929 19.2071 16.9929 18.898V10.0938H19.3811C19.3811 10.0938 19.3543 10.3126 19.414 10.6496ZM22.6846 13.2765V13.7663C22.4042 13.7023 22.1324 13.6077 21.8746 13.4843C21.375 13.2453 20.9859 12.856 20.9098 12.7773C20.9981 12.8328 21.0897 12.8834 21.1842 12.9287C21.7916 13.2193 22.3897 13.3061 22.6846 13.2765Z" fill="#69C9D0"/>
                            </svg>
                            </a>
                        </picture>
                    </div>
                </div>
                <h4>Uyên Camitie</h4>
            </div>
        </div>
    </section>
</div>
<section class="pockup-info">
    <div class="pockup-info-child">
        <div class="info-image">
            <div class="info-image-child">
                <picture>
                    <img src="./dist/img/Rectangle 15.png" alt="">
                </picture>
            </div>
            <div class="info-image-child">
                <picture>
                    <img src="./dist/img/Rectangle 15.png" alt="">
                </picture>
            </div>
            <div class="info-image-child">
                <picture>
                    <img src="./dist/img/Rectangle 15.png" alt="">
                </picture>
            </div>
            <div class="info-image-child">
                <picture>
                    <img src="./dist/img/Rectangle 15.png" alt="">
                </picture>
            </div>
        </div>
        <div class="info-detail">
            <h4>Little Yiyi</h4>
            <div class="info-detail-child">
                <h5>Thông tin cơ bản:</h5>
                <ul>
                    <li>Tên / nghệ danh phát sóng trực tiếp: Bloody-Xiao Yiyi </li>
                    <li>ID Tiktok: @yiyi12</li>
                    <li>Số người theo dõi: 658k</li>
                    <li>Số người hâm mộ trên mọi nền tảng: 2.01tr</li>
                    <li>Nhãn hiệu cá nhân: Ánh nắng hài hước, Hát hay</li>
                    <li>Vị trí: Hà Nội</li>
                </ul>
            </div>
            <div class="info-detail-child">
                <h5>Hồ sơ cá nhân</h5>
                <p>Ngoại hình ngọt ngào, xinh đẹp ca hát, tính cách hài hước, vui vẻ; Thu hút lượng lớn fan trên nền tảng phát sóng trực tiếp của Huya, mang đến niềm vui cho người hâm mộ mỗi ngày; top 10 tiktoker nổi tiếng nhất 2021.</p>
            </div>
            <div class="social">
                <h5>Social link</h5>
                <div class="social-link">
                <picture>
                                <a href="#">
                                    <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="17" cy="17.0002" r="14.1667" fill="#3B5998"/>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M20.7648 12.0119C20.3233 11.9236 19.7269 11.8577 19.3519 11.8577C18.3364 11.8577 18.2704 12.2992 18.2704 13.0056V14.2632H20.8089L20.5877 16.8682H18.2704V24.7918H15.092V16.8682H13.4583V14.2632H15.092V12.6519C15.092 10.4448 16.1293 9.2085 18.7338 9.2085C19.6386 9.2085 20.3009 9.34096 21.1616 9.51757L20.7648 12.0119Z" fill="white"/>
                                </svg>
                                </a>
                            </picture>
                            <picture>
                                <a href="#">
                                    <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="17" cy="17.0002" r="14.1667" fill="#1DA1F2"/>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M25.5 11.5518C24.875 11.8294 24.2024 12.0164 23.497 12.1009C24.2172 11.6691 24.7702 10.9857 25.0303 10.1715C24.3571 10.5715 23.6097 10.8611 22.8159 11.018C22.1796 10.3403 21.2724 9.9165 20.27 9.9165C18.344 9.9165 16.7824 11.4781 16.7824 13.4041C16.7824 13.6772 16.8136 13.9435 16.8731 14.1991C13.9742 14.054 11.4045 12.6652 9.68425 10.5551C9.38394 11.0702 9.21225 11.6691 9.21225 12.3082C9.21225 13.518 9.82704 14.5855 10.7637 15.2111C10.1914 15.193 9.65422 15.036 9.18335 14.7748V14.8184C9.18335 16.5087 10.3863 17.9179 11.9808 18.2392C11.6884 18.3185 11.3802 18.3615 11.0623 18.3615C10.8373 18.3615 10.6186 18.3394 10.4056 18.2986C10.8492 19.6841 12.1378 20.6927 13.6637 20.721C12.4704 21.6559 10.9665 22.2141 9.33238 22.2141C9.0502 22.2141 8.77255 22.1976 8.5 22.1648C10.0435 23.1541 11.8765 23.7321 13.8461 23.7321C20.2609 23.7321 23.7689 18.4176 23.7689 13.8092C23.7689 13.658 23.7661 13.5072 23.7588 13.3582C24.441 12.8652 25.0325 12.251 25.5 11.5518Z" fill="white"/>
                                </svg>
                                </a>
                            </picture>
                            <picture>
                                <a href="#">
                                    <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="17" cy="17.0002" r="14.1667" fill="#C13584"/>
                                <path d="M17 10.0315C19.2696 10.0315 19.5384 10.0402 20.4347 10.0811C21.2635 10.1189 21.7135 10.2573 22.0131 10.3738C22.4098 10.528 22.693 10.7121 22.9904 11.0096C23.2878 11.307 23.472 11.5902 23.6262 11.9869C23.7426 12.2864 23.8811 12.7365 23.9189 13.5653C23.9598 14.4615 23.9685 14.7304 23.9685 17C23.9685 19.2696 23.9598 19.5384 23.9189 20.4347C23.8811 21.2634 23.7426 21.7135 23.6262 22.013C23.472 22.4098 23.2878 22.6929 22.9904 22.9903C22.693 23.2878 22.4098 23.472 22.0131 23.6262C21.7135 23.7426 21.2635 23.8811 20.4347 23.9189C19.5386 23.9597 19.2698 23.9684 17 23.9684C14.7302 23.9684 14.4615 23.9597 13.5653 23.9189C12.7365 23.8811 12.2865 23.7426 11.9869 23.6262C11.5902 23.472 11.307 23.2878 11.0096 22.9903C10.7122 22.6929 10.528 22.4098 10.3738 22.013C10.2574 21.7135 10.1189 21.2634 10.0811 20.4347C10.0402 19.5384 10.0315 19.2696 10.0315 17C10.0315 14.7304 10.0402 14.4615 10.0811 13.5653C10.1189 12.7365 10.2574 12.2864 10.3738 11.9869C10.528 11.5902 10.7121 11.307 11.0096 11.0096C11.307 10.7121 11.5902 10.528 11.9869 10.3738C12.2865 10.2573 12.7365 10.1189 13.5653 10.0811C14.4616 10.0402 14.7304 10.0315 17 10.0315ZM17 8.5C14.6915 8.5 14.4021 8.50978 13.4955 8.55115C12.5907 8.59242 11.9728 8.73612 11.4322 8.94622C10.8732 9.16344 10.3992 9.45409 9.92663 9.92662C9.45409 10.3992 9.16345 10.8732 8.94626 11.4322C8.73612 11.9728 8.59242 12.5907 8.55115 13.4954C8.50978 14.4021 8.5 14.6915 8.5 17C8.5 19.3084 8.50978 19.5979 8.55115 20.5045C8.59242 21.4092 8.73612 22.0271 8.94626 22.5678C9.16345 23.1267 9.45409 23.6007 9.92663 24.0733C10.3992 24.5459 10.8732 24.8365 11.4322 25.0537C11.9728 25.2638 12.5907 25.4075 13.4955 25.4488C14.4021 25.4902 14.6915 25.4999 17 25.4999C19.3085 25.4999 19.5979 25.4902 20.5045 25.4488C21.4093 25.4075 22.0272 25.2638 22.5678 25.0537C23.1268 24.8365 23.6008 24.5459 24.0734 24.0733C24.5459 23.6007 24.8366 23.1267 25.0538 22.5678C25.2639 22.0271 25.4076 21.4092 25.4488 20.5045C25.4902 19.5979 25.5 19.3084 25.5 17C25.5 14.6915 25.4902 14.4021 25.4488 13.4954C25.4076 12.5907 25.2639 11.9728 25.0538 11.4322C24.8366 10.8732 24.5459 10.3992 24.0734 9.92662C23.6008 9.45409 23.1268 9.16344 22.5678 8.94622C22.0272 8.73612 21.4093 8.59242 20.5045 8.55115C19.5979 8.50978 19.3085 8.5 17 8.5Z" fill="white"/>
                                <path d="M17.0039 12.6392C14.5933 12.6392 12.6391 14.5934 12.6391 17.004C12.6391 19.4147 14.5933 21.3689 17.0039 21.3689C19.4146 21.3689 21.3688 19.4147 21.3688 17.004C21.3688 14.5934 19.4146 12.6392 17.0039 12.6392ZM17.0039 19.8373C15.4391 19.8373 14.1706 18.5688 14.1706 17.004C14.1706 15.4392 15.4391 14.1707 17.0039 14.1707C18.5687 14.1707 19.8373 15.4392 19.8373 17.004C19.8373 18.5688 18.5687 19.8373 17.0039 19.8373Z" fill="white"/>
                                <path d="M22.561 12.4639C22.561 13.0272 22.1043 13.4838 21.541 13.4838C20.9777 13.4838 20.521 13.0272 20.521 12.4639C20.521 11.9005 20.9777 11.4438 21.541 11.4438C22.1043 11.4438 22.561 11.9005 22.561 12.4639Z" fill="white"/>
                                </svg>
                                </a>
                            </picture>
                            <picture>
                                <a href="#">
                                    <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="17" cy="17.0002" r="14.1667" fill="#FF0000"/>
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M25.0045 11.6011C25.2872 11.8838 25.4909 12.2356 25.5953 12.6216C26.1966 15.042 26.0577 18.8646 25.607 21.3784C25.5026 21.7643 25.2989 22.1162 25.0162 22.3989C24.7335 22.6816 24.3817 22.8853 23.9957 22.9897C22.583 23.375 16.8968 23.375 16.8968 23.375C16.8968 23.375 11.2107 23.375 9.79794 22.9897C9.41203 22.8853 9.0602 22.6816 8.77751 22.3989C8.49481 22.1162 8.29111 21.7643 8.18668 21.3784C7.58187 18.9685 7.74767 15.1435 8.175 12.6332C8.27943 12.2473 8.48314 11.8955 8.76583 11.6128C9.04853 11.3301 9.40035 11.1264 9.78627 11.022C11.199 10.6367 16.8852 10.625 16.8852 10.625C16.8852 10.625 22.5713 10.625 23.9841 11.0103C24.37 11.1147 24.7218 11.3184 25.0045 11.6011ZM19.7924 17L15.0754 19.7321V14.2679L19.7924 17Z" fill="white"/>
                                </svg>
                                </a>
                            </picture>
                            <picture>
                                <a href="#">
                                    <svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <circle cx="17" cy="17.0002" r="14.1667" fill="#161414"/>
                                <path d="M12.9895 19.0146C13.0725 18.3272 13.3544 17.9424 13.8857 17.5478C14.6459 17.0135 15.5954 17.3158 15.5954 17.3158V15.5227C15.8262 15.5168 16.0572 15.5305 16.2855 15.5636V17.8711C16.2855 17.8711 15.3362 17.5688 14.5761 18.1034C14.0451 18.4977 13.7626 18.8828 13.6799 19.5702C13.6773 19.9435 13.7473 20.4314 14.0699 20.8533C13.9902 20.8124 13.9089 20.7658 13.826 20.7135C13.1155 20.2363 12.986 19.5205 12.9895 19.0146ZM20.2061 12.2074C19.6832 11.6344 19.4855 11.0558 19.414 10.6494H20.0718C20.0718 10.6494 19.9406 11.715 20.8965 12.763L20.9098 12.777C20.6521 12.615 20.4159 12.4237 20.2061 12.2074ZM23.375 13.8319V16.093C23.375 16.093 22.5355 16.0601 21.9143 15.902C21.047 15.681 20.4895 15.342 20.4895 15.342C20.4895 15.342 20.1044 15.1003 20.0732 15.0834V19.7526C20.0732 20.0125 20.002 20.6618 19.785 21.2033C19.5016 21.9117 19.0643 22.3767 18.9839 22.4717C18.9839 22.4717 18.452 23.1002 17.5138 23.5235C16.668 23.9053 15.9254 23.8956 15.7035 23.9053C15.7035 23.9053 14.4199 23.9562 13.2648 23.2055C13.015 23.04 12.7819 22.8527 12.5684 22.6458L12.5741 22.6499C13.7295 23.4005 15.0128 23.3497 15.0128 23.3497C15.2351 23.34 15.9776 23.3497 16.8231 22.9679C17.7605 22.5446 18.2932 21.9161 18.2932 21.9161C18.3728 21.8211 18.8121 21.3561 19.0943 20.6474C19.3108 20.1062 19.3826 19.4567 19.3826 19.1967V14.5281C19.4137 14.5452 19.7985 14.787 19.7985 14.787C19.7985 14.787 20.3563 15.1263 21.2237 15.347C21.8452 15.505 22.6843 15.5379 22.6843 15.5379V13.7661C22.9714 13.8305 23.2161 13.8479 23.375 13.8319Z" fill="#EE1D52"/>
                                <path d="M22.6846 13.7661V15.5374C22.6846 15.5374 21.8455 15.5045 21.224 15.3464C20.3566 15.1254 19.7988 14.7864 19.7988 14.7864C19.7988 14.7864 19.414 14.5447 19.3828 14.5276V19.1972C19.3828 19.4572 19.3116 20.1067 19.0946 20.648C18.8112 21.3566 18.3739 21.8216 18.2935 21.9167C18.2935 21.9167 17.7614 22.5452 16.8234 22.9684C15.9779 23.3503 15.2354 23.3406 15.0131 23.3503C15.0131 23.3503 13.7298 23.4011 12.5744 22.6504L12.5687 22.6463C12.4467 22.5282 12.3319 22.4035 12.2248 22.2728C11.8561 21.8233 11.6301 21.2917 11.5733 21.14C11.5732 21.1394 11.5732 21.1387 11.5733 21.1381C11.4819 20.8745 11.2899 20.2416 11.3162 19.6285C11.3626 18.5469 11.7431 17.883 11.8437 17.7166C12.1101 17.2631 12.4567 16.8573 12.8679 16.5173C13.2307 16.2239 13.642 15.9905 14.0849 15.8266C14.5637 15.6342 15.0763 15.531 15.5954 15.5227V17.3158C15.5954 17.3158 14.6459 17.0146 13.886 17.5478C13.3547 17.9424 13.0728 18.3272 12.9898 19.0146C12.9863 19.5205 13.1158 20.2363 13.8258 20.7137C13.9086 20.7662 13.9899 20.8128 14.0696 20.8535C14.1937 21.0148 14.3446 21.1552 14.5164 21.2693C15.21 21.7083 15.7911 21.739 16.5343 21.4539C17.0298 21.2632 17.4028 20.8336 17.5757 20.3576C17.6844 20.0603 17.683 19.7611 17.683 19.4517V10.6494H19.4125C19.484 11.0558 19.6818 11.6344 20.2047 12.2074C20.4144 12.4237 20.6507 12.615 20.9083 12.777C20.9844 12.8558 21.3736 13.2451 21.8731 13.484C22.1314 13.6076 22.4037 13.7022 22.6846 13.7661Z" fill="white"/>
                                <path d="M10.8849 20.5894V20.5907L10.9278 20.7071C10.9229 20.6935 10.907 20.6523 10.8849 20.5894Z" fill="#69C9D0"/>
                                <path d="M14.0849 15.8266C13.6421 15.9905 13.2308 16.2239 12.8679 16.5173C12.4566 16.858 12.1101 17.2647 11.844 17.7191C11.7434 17.8849 11.3629 18.5493 11.3165 19.631C11.2902 20.244 11.4822 20.877 11.5736 21.1406C11.5735 21.1412 11.5735 21.1419 11.5736 21.1425C11.6313 21.2928 11.8564 21.8244 12.2251 22.2752C12.3322 22.4059 12.447 22.5307 12.569 22.6488C12.1781 22.3897 11.8296 22.0765 11.5347 21.7194C11.1692 21.2737 10.9438 20.7477 10.885 20.5924C10.8849 20.5913 10.8849 20.5902 10.885 20.5891V20.5872C10.7933 20.3239 10.6007 19.6906 10.6275 19.0768C10.6739 17.9951 11.0544 17.3312 11.1551 17.1649C11.4211 16.7104 11.7675 16.3038 12.179 15.9631C12.5418 15.6696 12.9531 15.4362 13.396 15.2724C13.6723 15.1625 13.9601 15.0815 14.2544 15.0306C14.6981 14.9564 15.1511 14.95 15.5969 15.0116V15.5227C15.0773 15.5308 14.5641 15.634 14.0849 15.8266Z" fill="#69C9D0"/>
                                <path d="M19.414 10.6496H17.6844V19.4522C17.6844 19.7616 17.6844 20.06 17.5772 20.3581C17.4025 20.8338 17.0309 21.2635 16.5357 21.4541C15.7923 21.7403 15.2111 21.7085 14.5179 21.2695C14.3458 21.156 14.1944 21.0159 14.0699 20.8551C14.6606 21.1571 15.1892 21.1518 15.8442 20.8999C16.3391 20.7092 16.7112 20.2796 16.8854 19.8036C16.9943 19.5063 16.9929 19.2071 16.9929 18.898V10.0938H19.3811C19.3811 10.0938 19.3543 10.3126 19.414 10.6496ZM22.6846 13.2765V13.7663C22.4042 13.7023 22.1324 13.6077 21.8746 13.4843C21.375 13.2453 20.9859 12.856 20.9098 12.7773C20.9981 12.8328 21.0897 12.8834 21.1842 12.9287C21.7916 13.2193 22.3897 13.3061 22.6846 13.2765Z" fill="#69C9D0"/>
                                </svg>
                                </a>
                            </picture>
                </div>
            </div>
        </div>
    </div> 
</section>
<section class="why-monda">
    <div class="container">
        <div class="why-monda-text">
            <h4>Khách hàng chọn Monda vì</h4>
            <p>V-Top luôn mang đến sự hài lòng, là sự lựa chọn sáng giá được các đối tác ưu tiên tìm gặp hợp tác, đặt niềm tin vào sản phẩm dịch vụ của chúng tôi</p>
        </div>
        <div class="why-monda-list">
            <div class="why-monda-child">
                <div class="why-monda-child-image">
                    <picture>
                        <img src="./dist/img/video-play.png" alt="">
                    </picture>
                </div>
                <div class="why-monda-child-text">
                    <h4>Hơn 300</h4>
                    <p>Sản phẩm đã sản xuất</p>
                </div>
            </div>
            <div class="why-monda-child">
                <div class="why-monda-child-image">
                    <picture>
                        <img src="./dist/img/status-up.png" alt="">
                    </picture>
                </div>
                <div class="why-monda-child-text">
                    <h4>5 năm</h4>
                    <p>Hình thành và phát triển</p>
                </div>
            </div>
            <div class="why-monda-child">
                <div class="why-monda-child-image">
                    <picture>
                        <img src="./dist/img/user-tag.png" alt="">
                    </picture>
                </div>
                <div class="why-monda-child-text">
                    <h4>Hơn 200</h4>
                    <p>Khách hàng</p>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="container"> 
    <section class="event-news">
        <div class="event-news-title">
            <h4>Tin tức & Sự kiện</h4>
            <p>V-Top luôn mang đến sự hài lòng, là sự lựa chọn sáng giá được các đối tác ưu tiên tìm gặp hợp tác, đặt niềm tin vào sản phẩm dịch vụ của chúng tôi </p>
        </div>
        <div class="event-news-list">
            <div class="event-news-child">
                <picture>
                    <img src="./dist/img/Rectangle 2.png" alt="">
                </picture>
                <div class="event-news-child-text">
                    <p>
                        <img src="./dist/img/date.svg" alt="">
                        <span>24 tháng 12, 2021</span>
                    </p>
                    <h5>V-Top luôn mang đến sự hài lòng, là sự lựa chọn sáng giá được các đối tác </h5>   
                </div>        
            </div>
            <div class="event-news-child">
                <picture>
                    <img src="./dist/img/Rectangle 2.png" alt="">
                </picture>
                <div class="event-news-child-text">
                    <p>
                        <img src="./dist/img/date.svg" alt="">
                        <span>24 tháng 12, 2021</span>
                    </p>
                    <h5>V-Top luôn mang đến sự hài lòng, là sự lựa chọn sáng giá được các đối tác </h5>   
                </div>        
            </div>
            <div class="event-news-child">
                <picture>
                    <img src="./dist/img/Rectangle 2.png" alt="">
                </picture>
                <div class="event-news-child-text">
                    <p>
                        <img src="./dist/img/date.svg" alt="">
                        <span>24 tháng 12, 2021</span>
                    </p>
                    <h5>V-Top luôn mang đến sự hài lòng, là sự lựa chọn sáng giá được các đối tác </h5>   
                </div>        
            </div>
        </div>
    </section>
</div>
<div class="overlay"></div>
<?php include './footer.php' ?>